from django.urls import path

from django.conf.urls.static import static

from django.conf import settings
 
from . import views

app_name = "hive"

urlpatterns = [
    path("", view=views.displayHiveHomePage, name="home"),

    path("about/", view=views.displayHiveAboutPage, name="about"),

    path("contact/", view=views.displayHiveContactPage, name="contact"),

    path("appointment/", view=views.displayAppointmentPage, name='appointment'),

    path("login/", view=views.displayLoginPage, name='login'),

    path("logout/", view=views.logoutUser, name='logout'),

    path("validate/", view=views.validateSignIn, name='validate-login'),

    path("resolve-route/", view=views.determineRedirectRoute, name='resolve'),

    path("add-client/", view=views.registerNewClientUser, name='add-client'),

    path("dashboard/", view=views.displayUserAccount, name='dashboard'),

    path("signup/", view=views.displayClientSignup, name='signup'),

    path("control/", view=views.displayAdminHome, name='base'),

    path("get-events/", view=views.getCalendarEvents, name='collect-events'),

    path("user-list/", view=views.displayUserList, name='user-list'),

    path("personnel-dashboard/", view=views.displayDoctorsPanel, name='doc-dash'),

    path("add-staff/", view=views.registerNewStaff, name='add-staff'),

    path("resolve-verify/<str:linkCode>/", view=views.verifyUserEmail, name='verify-resolve'),

    path("initiate-reset/", view=views.requestResetLink, name='initiate-reset'),

    path("resolve-reset/<str:resetCode>/", view=views.acknowledgeReset, name='verify-reset'),

    path("verification-notice/", view=views.initiateEmailVerification, name='verify-notice'),

    path("do-verification/", view=views.sendVerificationLinkAgain, name='do-verification'),

    path("re-verify/", view=views.executeReverifyRoutine, name='re-verify'),

    path("revoke-access/", view=views.deleteUserAccount, name='revoke-access'),

    path("alter-password/", view=views.alterAccountPassword, name='alter-password'),

    path("change-avatar/", view=views.changeAvatar, name='update-avatar'),

    path("receive-message/", view=views.receiveSentMessage, name='receive-message'),

    path("whisper-seen/", view=views.executeSeenWhisper, name='seen-whisper'),

    path("dump-contact-message/", view=views.dumpContactMessage, name='contact-msg-dump'),

    path("wipe-all-cmsg/", view=views.wipeAllMessages, name='wipe-all-cmsg'),

    path("update-contact/", view=views.updateContactInformation, name='change-contact'),

    path("all-appointments/", view=views.displayAllPatientAppointments, name='user-appointments'),

    path('process-request', view=views.processAppointmentRequest, name='process-request'),

    path("withdraw-request/<str:appointmentId>/", view=views.executeAppointmentCancellation, name='cancel-appointment'),

    path("dump-request/", view=views.executeAppointmentWipe, name='dump-appointment'),

    path("approve-appointment/", view=views.approveAppointmentRequest, name='approve-appointment'),

    path("communicate-cancelled/", view=views.cancelAppointmentAndNotify, name='cancel-notify'),

    path("tag-complete/", view=views.markAppointmentAsComplete, name='mark-complete'),

    path("cancel-approved/", view=views.cancelMyAppointment, name='cancel-approved'),

    path("fetch-appointments/", view=views.fetchMyAppointments, name='get-appointments'),

    path("reports/", view=views.viewReportsPage, name='view-reports'),

    path("export-report/", view=views.exportCustomerList, name='export-report'),

    path("chat/<str:fromTag>/", view=views.loadChatMessages, name='load-chats'),

    path("send-message/", view=views.pushChatMessage, name='send-message'),

    path("dump-chat/<str:messageTag>/<str:fromTag>/", view=views.deleteSelectedMessage, name='dump-message'),

    path("delete-alerts/", view=views.wipeMyAlerts, name='wipe-alerts'),
]


# avoid redirects
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# load static files even in debug -> False
if (settings.FORCE_STATIC_FILE_SERVING is True and settings.DEBUG is False):
    # first revert debug
    settings.DEBUG = True
    
    # load these urls
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    
    # change to debug
    settings.DEBUG = False
    
else:
    # the loaded urls are enough
    pass
    
    