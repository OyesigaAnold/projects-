from django.contrib import admin

from .models import UserProfile, AppointmentItem, UserProfile, CustomerDetails, NotificationAlertItem

from import_export import resources # type: ignore


admin.site.register(UserProfile)

admin.site.register(AppointmentItem)

admin.site.register(NotificationAlertItem)


class CustomerResource(resources.ModelResource):
    class Meta:
        # model to use
        model = CustomerDetails

        # fields i want rendered
        fields = ['clientName', 'clientContact']

        # alter the order
        export_order = ['clientName', 'clientContact']