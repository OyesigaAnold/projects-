from .models import (
    UserProfile, AppointmentItem, VerificationLink, 
    ResetLink, MessageItem, AdminContact,
    HistoryItem, CustomerDetails, ChatContact, ChatMessage, NotificationAlertItem
    )

from .admin import CustomerResource

from django.http import HttpRequest, HttpResponse

from django.contrib.auth.models import User

import secrets

from datetime import datetime, timedelta

from django.core.mail import EmailMessage

from django.template.loader import render_to_string

from django.utils import timezone

from django.db.models import Q


class AlertTools:
    def deleteAttachedAlerts(self, userObject:User):
        myAlerts = userObject.my_notifications.all()

        myAlerts.delete()

        return

    def sendAlert(self, recipientUser:User, alertMessage:str):
        # create new alert
        newAlert = NotificationAlertItem.objects.create(
            associatedUser=recipientUser,
            attachedMessage=alertMessage.strip()
        )

        newAlert.save()


        return
    
    def loadMyAlerts(self, attachedUser:User, whereToLoad:dict):
        # get all alerts
        myAlerts = attachedUser.my_notifications.all()

        formattedAlerts = [

            {
                'date': BasicTools().castToTimeZone(eachAlert.sentDate).strftime('%d %b, %Y At %I:%M %p'),
                'message': eachAlert.attachedMessage,
                'today': eachAlert.alertForToday()

            } for eachAlert in myAlerts
        ]

        if len(formattedAlerts) > 0:
            # load
            whereToLoad['found_alerts'] = formattedAlerts

        else:
            pass

        return


class ChatTools:
    def getUserViaProfileTag(self, profileTag:str):
        # get the profile
        attachedProfile = UserProfile.objects.filter(userId=profileTag).first()

        return attachedProfile.userInstance

    
    def deleteChatMessage(self, chatMessageTag:str):
        # get the message
        attachedChatMessage = ChatMessage.objects.filter(messageId=chatMessageTag).first()

        # debug
        wasDeleted = False

        if attachedChatMessage:
            attachedChatMessage.delete()

            wasDeleted = True

        else:
            # its a broken link
            pass

        return wasDeleted

    

    
    def getReceptionistAccountUser(self):
        # admin
        adminEmail = 'physiohealthmedical@gmail.com'

        # admin user
        adminUserInstance = User.objects.filter(email=adminEmail).first()

        # print('Admin:', adminUserInstance)

        return adminUserInstance

        
    
    def recordChatMessage(self, senderUserObject:User, toWhoTag:str, messageContent:str):
        # is admin
        involvesAdmin = False

        # pass
        if toWhoTag == 'phm':
            # get admin user object
            messageRecipient = self.getReceptionistAccountUser()

            # contains admin chats
            involvesAdmin = True

            # print("Its an admin")

        else:
            # get the user object via their profile ta
            messageRecipient = self.getUserViaProfileTag(profileTag=toWhoTag)

            # print("Its a nother user")

            # when the sender is an admin
            if senderUserObject.is_staff:
                involvesAdmin = True

            else:
                pass


        # print('ToWho:', messageRecipient)
        
        # new message
        newChatMessage= ChatMessage.objects.create(
            toWho=messageRecipient,
            fromWho=senderUserObject,
            messageContent=messageContent,
            involvesAdmin=involvesAdmin
        )

        newChatMessage.save()

        AlertTools().sendAlert(recipientUser=messageRecipient, alertMessage='You have a new message from {}'.format(senderUserObject.username))

        return


    

        
    
    def formatChatMessage(self, messageObject:ChatMessage, userName:str):
        fromName = messageObject.fromWho.username

        toWhoName = messageObject.toWho.username

        # format the message
        formattedMessage = {
            'message': messageObject.messageContent,
            # 12, Jan, 2024
            'date': messageObject.createdDate.strftime('%d, %b, %Y'),
            'time': messageObject.createdDate.strftime('%I:%M %p'),
            'from_name': 'You' if fromName == userName else fromName,
            'to_name': toWhoName,
            'id': messageObject.messageId,
            'admin_part': messageObject.involvesAdmin
        }


        # alignment of the message
        formattedMessage['position'] = 2 if fromName == userName else 1


        return formattedMessage

    def getChatsWith(self, requestObject:HttpRequest, fromTag:str, whereToLoad:dict):
        # get the user object
        userObject = requestObject.user

        # get the user object via the profile tag
        # returns a: User Object
        userToTarget = self.getReceptionistAccountUser() if fromTag == 'phm' else self.getUserViaProfileTag(profileTag=fromTag)

        messageRecipient = userToTarget.username

        # from or to the given user name
        messageFromOrToUser = Q(toWho=userToTarget, fromWho=userObject) | Q(fromWho=userToTarget, toWho=userObject)

        # collect the messages
        allMessages = ChatMessage.objects.filter(messageFromOrToUser).order_by("createdDate").all()

        
        # current users name
        currentUsersName = userObject.username
        
        # collects formatted messages
        formattedChats = []

        # format the chats
        for eachMessage in allMessages:
            chatFormatted = self.formatChatMessage(messageObject=eachMessage, userName=currentUsersName)


            # store the formatted chat
            formattedChats.append(chatFormatted)

            if (eachMessage.toWho == userObject) and (eachMessage.toSeen is False):
        
                 # mark it seen if its mine and appears not to be seen
                eachMessage.toSeen = True

                eachMessage.save()

                # debug
                # print('Marked seen')

            else:
                # its not mine or its already seen
                pass



        # debug
        # print(formattedChats)


        # load them to the context

        whereToLoad['my_chat_messages'] = formattedChats


        # allow chat for this user
        whereToLoad['is_chat_active'] = True

        whereToLoad['recipient'] = messageRecipient

        whereToLoad['to_who_tag'] = fromTag


        return


        

    def chatContactExists(self, requestObject:HttpRequest, contactTag:str):
        contactPresent = False

        # status
        userStatus = requestObject.session['details']['status']

        if contactTag == 'phm':
            if userStatus == 2:
                pass

            else:
                contactPresent = True

        else:
            # use thr profile to determine if the user exists for both admin and doctors or patient
            profileObject = UserProfile.objects.filter(userId=contactTag).first()

            if userStatus in [0, 1]:
                if profileObject:
                    # validate the user is among the contact list
                    attachedUser = profileObject.userInstance

                    if userStatus == 0:
                        userInListCount = requestObject.user.my_doctors.filter(contactDetail=attachedUser).count()

                    else:
                        userInListCount = requestObject.user.my_patients.filter(associatedUser=attachedUser).count()

                    # check the count 
                    contactPresent = userInListCount > 0


                else:
                    pass

            else:
                # validate if its a valid user with a profile: doctor or patient
                contactPresent = True if profileObject else False 

        return contactPresent
    
    def countMessagesFromThem(self, fromUser:User, toUser:User, chatsCount:list):
        # from user
        messagesFromUser = Q(fromWho=fromUser, toWho=toUser, toSeen=False)

        # collect the messages
        messageCount = ChatMessage.objects.filter(messagesFromUser).count()

        # track the count
        chatsCount += [messageCount]

        return messageCount 


    def loadUserContacts(self, requestObject:HttpRequest, whereToLoad:dict, whoseChats:str=None):
        userStatusTag =  requestObject.session['details']['status']

        presentChatContacts = []

        # chats count
        chatsCount = []

        # get user object
        attachedUser = requestObject.user

        if userStatusTag == 2:
            allProfiles = UserProfile.objects.filter(isVerified=True).all()

        else:
            # get the user objects
            allContacts = ChatContact.objects.filter(associatedUser=attachedUser).all() if userStatusTag == 0 else ChatContact.objects.filter(contactDetail=attachedUser).all()

            allProfiles = [(eachChatContact.contactDetail.other_details if userStatusTag == 0 else eachChatContact.associatedUser.other_details) for eachChatContact in allContacts]

            # messages from admin
            adminMessageCount = self.countMessagesFromThem(fromUser=self.getReceptionistAccountUser(), toUser=attachedUser, chatsCount=chatsCount)

            presentChatContacts += [
                {
                    'count': adminMessageCount,
                    'tag': 'phm',
                    'name': 'PHM Receptionist',
                    'status': 2,
                    'mine':  'phm' == whoseChats
                }
            ]


        # format the found contacts
        presentChatContacts += [
            {
                'count': self.countMessagesFromThem(fromUser=eachProfile.userInstance, toUser=attachedUser, chatsCount=chatsCount),
                'tag': eachProfile.userId,
                'name': eachProfile.userInstance.username if eachProfile.statusTag == 0 else 'Dr.{}'.format(eachProfile.userInstance.username),
                'status': eachProfile.statusTag,
                'mine': eachProfile.userId == whoseChats

            } for eachProfile in allProfiles
        ]

        # print('contacts:', len(presentChatContacts))

        whereToLoad['total_chats_count'] = sum(chatsCount)

        # load contacts
        if len(presentChatContacts) > 0:
            whereToLoad['my_chat_contacts'] = presentChatContacts

        else:
            # ignore
            pass

        return

    
    def addChatContact(self, associatedDoctor:User, associatedClient:User):
        # duplicates
        connectionsCount = ChatContact.objects.filter(contactDetail=associatedDoctor, associatedUser=associatedClient).count()

        if connectionsCount > 0:
            # already connected
            pass

        else:
            # create a connection
            newConnection = ChatContact.objects.create(
                associatedUser=associatedClient,
                contactDetail=associatedDoctor
            )

            newConnection.save()

        return

class ExportUtilities:
    def __init__(self) -> None:
        pass

    def getCustomerData(self):
        # get those that are verified
        verifiedClients = UserProfile.objects.filter(isVerified=True, statusTag=0).all().values_list("userInstance")

        # get customers there
        customerList = CustomerDetails.objects.filter(attachedOwner__in=verifiedClients).all()

        return customerList


    def dumpCustomerList(self):
        # get the data
        feedData = self.getCustomerData()

        # debug
        # print("count:", feedData.count())

        if feedData.count() == 0:
            # print("returning none")
            return None

        else:
            # am processing
            pass


        # prepare to export
        generatedDataset = CustomerResource().export(feedData)

        # exported data
        exportedData = generatedDataset.xls

        # print("Format wanted:", generatedDataset)
        exportFormat = 'xlsx'


        fileSuffix = datetime.now().strftime("_on_%d_%b_%Y_At_%I_%M_%S_%p")

        # prepare for export
        replyResponse = HttpResponse(exportedData, content_type=f"{exportFormat}")

        replyResponse['Content-Disposition'] = f"attachment; filename=Client List{fileSuffix}.{exportFormat}"

        return replyResponse


class ReportTools:
    def loadCustomerAvatarOrInitials(self, customerProfile:UserProfile, customerMeta:dict):
        # get the profile
        if customerProfile.hasAvatar() is True:
            customerMeta['avatar'] = customerProfile.userImage

        else:
            customerMeta['initials'] = BasicTools().generateUserInitials(userName=customerMeta['name'])

        return


    def loadClientList(self, whereToLoad:dict):
        # get clients
        verifiedCustomers = UserProfile.objects.filter(isVerified=True, statusTag=0).all()

        # collect
        formattedUsers = [] 
        
        for eachUserDetail in verifiedCustomers:
            # format
            # loadUserAvatar
            customerUserInstance = eachUserDetail.userInstance

            # name of the customer
            customerName = customerUserInstance.username

            # details
            customerDetail = {
                'name': customerName,
                'contact': eachUserDetail.userContact
            }

            # get the profile
            attachedProfile:UserProfile = customerUserInstance.other_details

            # load the avatar
            self.loadCustomerAvatarOrInitials(customerProfile=attachedProfile, customerMeta=customerDetail)

            # store
            formattedUsers.append(customerDetail)

        # debug
        # formattedUsers = []

        if len(formattedUsers) > 0:
            whereToLoad['available_users'] = formattedUsers

        else:
            pass

        # avatar

        return


class ContactTools:
    def getContactInfoForAdmin(self):
        return AdminContact.objects.first()
    
    def getAdminContact(self):
        # get admin object
        adminContactItem = self.getContactInfoForAdmin()

        # format
        formattedContact = adminContactItem.companyContact if adminContactItem else ''

        return formattedContact
    
    def getUserContact(self, userObject:User):
        # get their profile
        foundContact = userObject.other_details.userContact

        return foundContact
    
    def alterContactInformation(self, contactMeta:dict, requestObject:HttpRequest):
        # status
        userStatus = int(requestObject.session['details']['status'])

        userContact = contactMeta['new-contact']

        formattedContact = f'+256{userContact}'

        if userStatus in [0, 1]:
            # user
            attachedUser = requestObject.user

            # update
            attachedProfile:UserProfile = attachedUser.other_details

            attachedProfile.userContact = formattedContact

            attachedProfile.save()

            # update the image of the client
            if userStatus == 0:
                Authenticator().monitorCustomerImage(attachedUser=attachedUser, userContact=attachedProfile.userContact)

            else:
                # doctor
                pass

            messageInfo = 'Your contact information was updated successfully'

        else:
            # get admin object
            adminContactItem = self.getContactInfoForAdmin()

            if adminContactItem:
                pass

            else:
                # create new object
                adminContactItem = AdminContact.objects.create()

            # update
            adminContactItem.companyContact = formattedContact

            adminContactItem.save()

            messageInfo = 'Your Company telephone contact was updated successfully'

        # update the session
        requestObject.session['details']['contact'] = formattedContact

        # inform django that the session data was modified
        requestObject.session.modified = True


        AlertTools().sendAlert(recipientUser=requestObject.user, alertMessage=messageInfo)

        return messageInfo








class MessageTools:
    def createMessageItem(self, messageMeta:dict):
        # extract the details
        newMessage = MessageItem.objects.create(
            senderName=messageMeta['sender-name'].strip().title(),
            senderEmail=messageMeta['sender-email'],
            senderContact=messageMeta['sender-contact'],
            sentMessage=messageMeta['sent-message']
        )

        newMessage.save()

    
    def wipeMessageItem(self, messageMeta:dict):
        # get the tag
        messageId = messageMeta['msg_tag']

        # get the message to wipe
        messageToDelete = MessageItem.objects.filter(messageId=messageId).first()

        # delete it
        messageToDelete.delete()

        return


    
    def loadContactMessagesAndCount(self, whereToLoad:dict):
        # get those not seen yet
        thoseNotSeenCount = MessageItem.objects.filter(messageSeen=False).count()

        # print('Not seen:', thoseNotSeenCount)

        whereToLoad['contact_message_count'] = thoseNotSeenCount

        # load the messages
        self.appendAllMessages(whereToLoad=whereToLoad)

        return
    
    def makeMessagesSeen(self):
        # get all those not seen
        messagesSeenNow = MessageItem.objects.filter(messageSeen=False).all()

        # mark them seen
        for eachMessage in messagesSeenNow:
            eachMessage.messageSeen = True

            eachMessage.save()

        return
    
    def formatMessageItem(self, messageObject:MessageItem):
        # format the message
        formattedMessage = {
            'id': messageObject.messageId,
            'stamp': messageObject.dateSent.strftime('On %d, %b, %Y At %I:%M %p'),
            'sender': messageObject.senderName,
            'email': messageObject.senderEmail,
            'phone': messageObject.senderContact,
            'message': messageObject.sentMessage
        }

        return formattedMessage

    
    def appendAllMessages(self, whereToLoad:dict):
        # get all
        allMessages = MessageItem.objects.all()

        # format them
        formattedMessageItems = [self.formatMessageItem(messageObject=eachMessageItem) for eachMessageItem in allMessages]

        if len(formattedMessageItems) > 0:
            whereToLoad['contact_messages'] = formattedMessageItems

        else:
            pass

        return

    
    def cleanUpContactMessages(request):
        # wipe all messages
        allMessages = MessageItem.objects.all()

        # execute
        allMessages.delete()


        return


class FetchTools:
    def getProfileViaTag(self, profileTag:str):
        return UserProfile.objects.filter(userId=profileTag).first()

    def formatStaffUser(self, staffObject:UserProfile):
        # get status
        hasAvatar = staffObject.hasAvatar()

        # name
        userName = staffObject.userInstance.username

        # load the details
        formattedDetails = {
            'name': userName,
            'role': staffObject.userRole,
            'contact': staffObject.getUserContact(),
            'profTag': staffObject.userId,
            'email': staffObject.userInstance.email
        }

        if hasAvatar is True:
            # load the avatar
            formattedDetails['avatar'] = staffObject.userImage

        else:
            # load initials
            formattedDetails['initials'] = BasicTools().generateUserInitials(userName=userName)

        return formattedDetails
    
    def loadAvailableStaff(self, whereToLoad:dict):
        # get the staff
        availableUsers = UserProfile.objects.filter(statusTag=1).all()

        # get their details
        userDetails = [self.formatStaffUser(staffObject=eachStaffUser) for eachStaffUser in availableUsers]

        if len(userDetails) > 0:
            # load
            whereToLoad['system_users'] = userDetails

        else:
            pass

        # debug
        # print(userDetails)

        return
    
    def loadStaffList(self, whereToLoad:dict):
        # get the staff
        availableUsers = UserProfile.objects.filter(statusTag=1).all()

        # get staff list
        staffMemberList = [eachStaffUser.userInstance.username for eachStaffUser in availableUsers]

        # debug
        # print(staffMemberList)

        if len(staffMemberList) > 0:
            # load
            whereToLoad['staff_member_list'] = sorted(staffMemberList)

        else:
            pass

        return
    


class ResetTools:
    def resetCodeIsValid(self, resetCode:str):
        # count
        resetLink = ResetLink.objects.filter(resetId=resetCode).first()

        return (not resetLink is None), (resetLink if resetLink is None else resetLink.ownerEmail)
    
    def executePasswordReset(self, userEmail:str):
        # get the account
        userObject = User.objects.filter(email=userEmail).first()

        # get new password
        newPassword = Authenticator().generateRandomPasswords()

        # change the password
        userObject.set_password(raw_password=newPassword)

        # pass
        userObject.save()

        # discard any links if any
        self.discardAnyResetLinks(userEmail=userEmail)

        # send new password to user's email
        NotificationsManager().issueNewPassword(userName=userObject.username, userEmail=userEmail, temporaryPassword=newPassword)


        AlertTools().sendAlert(recipientUser=userObject, alertMessage='The password of this account was reset')
        return
    



    def userExistsViaEmail(self, claimingEmail:str):
        # email
        claimingUser = User.objects.filter(email=claimingEmail).first()

        # status
        userPresent = not claimingUser is None

        return userPresent, claimingUser
    
    def issueResentLink(self, userObject:User):
        # details
        userEmail = userObject.email

        # wipe previous if any
        self.discardAnyResetLinks(userEmail=userEmail)

        # generate new
        newResetLink = ResetLink.objects.create(
            ownerEmail=userEmail
        )

        # cache the link
        newResetLink.save()

        # attain reset code
        resetCode = newResetLink.resetId

        NotificationsManager().sendPasswordResetLink(
            linkCode=resetCode,
            userName=userObject.username,
            userEmail=userEmail
        )

        # send an alert
        AlertTools().sendAlert(recipientUser=userObject, alertMessage='A password reset link was requested for this account')

        return
    
    def discardAnyResetLinks(self, userEmail:str):
        # find any links attached to the user
        userLinks = ResetLink.objects.filter(ownerEmail=userEmail).all()

        # delete all
        userLinks.delete()

        return

class VerificationTools:
    def recordTheVerification(self, linkId:str):
        # get the link
        linkObject = VerificationLink.objects.filter(itemId=linkId).first()

        # update the account that the email was verified
        attachedProfile = FetchTools().getProfileViaTag(
            profileTag=linkObject.profileTag
        )

        attachedProfile.isVerified = True

        attachedProfile.save()

        # delete the link now
        linkObject.delete()


        AlertTools().sendAlert(recipientUser=attachedProfile.userInstance, alertMessage='Welcome aboard PHM Medical, you is now verified')

        return


    def isCodeValid(self, linkCode:str):
        linksFound = VerificationLink.objects.filter(itemId=linkCode).count()

        # status
        isCodePresent = linksFound > 0

        return isCodePresent

    def linkSentAlready(self, userEmail:str):
        # count how many links exist already
        presenceCount = VerificationLink.objects.filter(attachedUserEmail=userEmail).count()

        # status
        linkExists = presenceCount > 0

        return linkExists
    
    def deleteAnyExistingLinks(self, userEmail:str):
        # wipe any existing links
        existingLinks = VerificationLink.objects.filter(attachedUserEmail=userEmail).all()

        # delete them
        existingLinks.delete()

        return


    def issueNewVerificationLink(self, userObject:User):
        # email
        attachedUserEmail = userObject.email


        # delete all 
        self.deleteAnyExistingLinks(userEmail=attachedUserEmail)

        # id of the user
        profileTag = userObject.other_details.userId

        # write a new one
        newLink = VerificationLink.objects.create(
            attachedUserEmail=attachedUserEmail,
            profileTag=profileTag
        )

        # write the link to the database
        newLink.save()

        # send an email to the user
        linkId = newLink.itemId

        NotificationsManager().sendVerificationLink(
            linkCode=linkId,
            userName=userObject.username,
            userEmail=userObject.email
        )

        return




class NotificationsManager:
    def __init__(self) -> None:
        pass

    def notifyDoctorAndPatient(self, emailMeta:dict):
        # 'doc_name'
        # 'doc_email'
        # 'client_name'
        # 'client_email'
        # 'date'

        
        # alert
        self.sendEmailMessage(emailInformation={
            'name': emailMeta['client_name'],
            'date': emailMeta['date'],
            'doctor': emailMeta['doc_name'],
            'type': 8

        }, mailReceiver=emailMeta['client_email'])

        self.sendEmailMessage(emailInformation={
            'name': "Dr.{}".format(emailMeta['doc_name']),
            'date': emailMeta['date'],
            'patient': emailMeta['client_name'],
            'type': 9

        }, mailReceiver=emailMeta['doc_email'])

        return


    def notifyDoctorOfApproval(self, emailMeta:dict, userEmail:str):
        # append the type
        emailMeta['type'] = 7
        
        # alert
        self.sendEmailMessage(emailInformation=emailMeta, mailReceiver=userEmail)

        return

    def notifyClientOfApproval(self, emailMeta:dict, userEmail:str):
        # append the type
        emailMeta['type'] = 6
        
        # alert
        self.sendEmailMessage(emailInformation=emailMeta, mailReceiver=userEmail)

        return

    def pushSorryMessage(self, userName:str, userEmail:str):
        emailMeta = {
            'type': 5,
            'name': userName,   
        }
        
        # alert
        self.sendEmailMessage(emailInformation=emailMeta, mailReceiver=userEmail)

        return
    

    def issueNewPassword(self, userName:str, userEmail:str, temporaryPassword:str):
        emailMeta = {
            'type': 3,
            'name': userName,
            'key': temporaryPassword     
        }
        
        # alert
        self.sendEmailMessage(emailInformation=emailMeta, mailReceiver=userEmail)

        return

    def sendPasswordResetLink(self, linkCode:str, userName:str, userEmail:str):
        emailMeta = {
            'type': 2,
            'name': userName,
            'code': linkCode     
        }
        
        # alert
        self.sendEmailMessage(emailInformation=emailMeta, mailReceiver=userEmail)

        return

    def sendVerificationLink(self, linkCode:str, userName:str, userEmail:str):
        emailMeta = {
            'type': 0,
            'name': userName,
            'code': linkCode     
        }
        
        # alert
        self.sendEmailMessage(emailInformation=emailMeta, mailReceiver=userEmail)

        return

    def notifyStaffOfAccessGrant(self, staffName:str, emailAddress:str, temporaryPassword:str):
        # the type: 1 - grant user access
        emailMeta = {
            'type': 1,
            'name': staffName,
            'email': emailAddress,
            'password': temporaryPassword        
        }
        
        # alert
        self.sendEmailMessage(emailInformation=emailMeta, mailReceiver=emailAddress)

        return

    
    def createEmailMessageAndBody(self, emailMeta:dict):
        # get the mail type
        # 0 - verify account
        # 1 - grant staff access
        # 2 - pre reset
        # 3 - post reset
        # 4 - welcome
        # 5 - delete account
        
        headingsMap = {
            0: '🥳 Verify your email address',
            1: 'Hey PHM staff 😇, You have been granted access',
            2: '🤔 Did you request a password reset for your PHM account',
            3: 'Here is your temporary password 😌',
            4: 'We are excited 👏 to have your aboard the PHM ship',
            5: '😌 We really feel bad, dont go like that',
            6: '👏 Your appointment has been confirmed',
            7: '👨‍⚕️ An appointment has been added to your task list',
            8: '❌ Your appointment was cancelled',
            9: '❌ An appointment was cancelled'
        }

        # get the type
        emailType = emailMeta['type']

        # get a heading from the map
        emailHeading = headingsMap[emailType]


        # context
        mailContext = {
        }


        # create context
        if emailType == 0 or emailType == 2:
            mailContext['name'] = emailMeta['name']

            mailContext['code'] = emailMeta['code']

        elif emailType == 1:
            mailContext['name'] = emailMeta['name']

            mailContext['email'] = emailMeta['email']

            mailContext['password'] = emailMeta['password']

        elif emailType == 3:
            mailContext['name'] = emailMeta['name']

            mailContext['key'] = emailMeta['key']

        elif emailType == 4:
            pass

        elif emailType == 5:
            # wipe account
            mailContext['name'] = emailMeta['name']

        elif emailType in [6, 7]:
            mailContext = emailMeta

        else:
            mailContext = emailMeta


        # generate the email body
        if emailType == 0:
            emailBody = render_to_string("core/mail/verify.html", mailContext)

        elif emailType == 1:
            emailBody = render_to_string("core/mail/access.html", mailContext)

        elif emailType == 2:
            emailBody = render_to_string("core/mail/pre.html", mailContext)

        elif emailType == 3:
            emailBody = render_to_string("core/mail/post.html", mailContext)

        elif emailType == 4:
            emailBody = render_to_string("core/mail/post.html", mailContext)

        elif emailType == 5:
            emailBody = render_to_string("core/mail/sorry.html", mailContext)

        elif emailType == 6:
            emailBody = render_to_string("core/mail/appointment.html", mailContext)

        elif emailType == 7:
            emailBody = render_to_string("core/mail/task.html", mailContext)

        elif emailType == 8:
            emailBody = render_to_string("core/mail/client-cancel.html", mailContext)

        else:
            # wipe
            emailBody = render_to_string("core/mail/doc-cancel.html", mailContext)


        return emailHeading, emailBody
    
    
    def sendEmailMessage(self, emailInformation:dict, mailReceiver:str):
        emailHeading, emailBody = self.createEmailMessageAndBody(emailMeta=emailInformation)

        # print(emailHeading, emailBody)

        # print(mailReceiver)

        # create a new email message
        emailMessage = EmailMessage(emailHeading, emailBody, 'phsyiohealthmedical@gmail.com', [mailReceiver])

        # message contains html
        emailMessage.content_subtype = 'html'

        # send the message
        emailMessage.send()

        # print('sent the email')

        return

class TimeTools:
    def generateGapDates(self, startDateString:str, endDateString:str):
        # Convert string dates to datetime objects
        start_date = datetime.strptime(startDateString, '%Y-%m-%d')

        end_date = datetime.strptime(endDateString, '%Y-%m-%d')

        # Initialize list to store generated dates
        all_dates = []

        # Loop through dates and generate all dates in between
        current_date = start_date
        while current_date <= end_date:
            all_dates.append(current_date.strftime('%Y-%m-%d'))
            current_date += timedelta(days=1)

        return all_dates
    
    def generateDatesWithinGap(self, startDate:str, endDate:str):
        # get the dates
        # ['2024-02-19', '2024-02-20', '2024-02-21']
        foundDates = self.generateGapDates(startDateString=startDate, endDateString=endDate)

        return foundDates


class BasicTools:
    def castToTimeZone(self, dateTimeObject:datetime):
        # Convert the current time to the desired timezone
        changedTimeZoneInfo = dateTimeObject.astimezone(timezone.get_current_timezone())

        return changedTimeZoneInfo
    
    def loadUserAvatar(self, requestObject:HttpRequest):
        # get status
        currentStatus = requestObject.session['details']['status']

        if currentStatus == 0 or currentStatus == 1:
            # load the avatar or initials
            foundProfile:UserProfile = requestObject.user.other_details
            
            # check if the avatar is present
            avatarPresent = foundProfile.hasAvatar()

            if avatarPresent is True:
                requestObject.session['profile'] = {
                    'avatar':foundProfile.userImage
                }

            else:
                requestObject.session['profile'] = {
                    'initials':self.generateUserInitials(userName=requestObject.user.username)
                }

        else:
            # admins have no avatar
            pass

        return



    def updateUserAvatar(self, requestObject:HttpRequest, newAvatar:str):
        userObject = requestObject.user

        # get the attached profile
        attachedProfile:UserProfile = userObject.other_details

        # make the update
        attachedProfile.userImage = newAvatar

        attachedProfile.save()

        # update avatar
        self.loadUserAvatar(requestObject=requestObject)

        return


    def generateUserInitials(self, userName:str):
        # get the users object

        nameList = userName.split(" ", 2)

        userInitials = ''.join((nameList[0][0].upper(), nameList[1][0].upper())) if len(nameList) == 2 else nameList[0][0].upper()

        # print('initials:', userInitials)

        return userInitials

    def constructDateTimeObject(self, dateString:str, timeString:str):
        # merge
        # '5:51 PM'
        dateTimeObject = datetime.strptime(f"{dateString} {timeString}", "%Y-%m-%d %I:%M %p")

        # print('Time:', dateTimeObject)

        # make the object time zone aware
        timeZoneAwareTime = dateTimeObject.astimezone(timezone.get_current_timezone())

        return timeZoneAwareTime
    

class AppointmentTools:
    def loadWorkingHistory(self, doctorUserObject:User, whereToLoad:dict):
        # get all the appointments
        workingHistory = doctorUserObject.my_history.all()

        # my_history
        formattedHistory = [
            {
                'stamp': eachHistoryItem.timeAndDate,
                'patient': eachHistoryItem.patientMetWith,
                'method': eachHistoryItem.meetingMethod

            } for eachHistoryItem in workingHistory
        ]

        if len(formattedHistory) > 0:
            # load
            whereToLoad['marked_history'] = formattedHistory

        else:
            pass

        return

    def getAppointmentById(self, appointmentId:str):
        return AppointmentItem.objects.filter(appointmentId=appointmentId).first()
    

    def writeNewHistoryItem(self, appointmentId:str):
       # get the appointment
        attachedAppointment = self.getAppointmentById(appointmentId=appointmentId)

        # doctors name
        doctorsName = attachedAppointment.meetingWith

        appointmentDate = BasicTools().castToTimeZone(attachedAppointment.appointmentDate).strftime('%d, %b, %Y At %I:%M %p')

        # get the doctor
        doctorDetail = self.getDoctorEmailViaName(
                doctorsName=doctorsName,

                doctorWanted=True
        )

        patientName = attachedAppointment.attachedOwner.username

        # created a new history item
        historyObject = HistoryItem.objects.create(
            attachedDoctor=doctorDetail,

            patientMetWith=patientName,

            timeAndDate=appointmentDate,

            meetingMethod=('Physical' if attachedAppointment.meetingType == 1 else 'Online')
        )

        # save
        historyObject.save()


        AlertTools().sendAlert(recipientUser=doctorDetail, alertMessage='An appointment dated {} with {} was marked complete by the receptionist'.format(
            appointmentDate,
            patientName
        ))


        # delete the appointment
        attachedAppointment.delete()

        return doctorsName, appointmentDate


    def executeCancelAndNotify(self, appointmentId:str):
        # get the appointment
        attachedAppointment = self.getAppointmentById(appointmentId=appointmentId)

        # get the doctors name, email, patient name and email
        doctorsName = attachedAppointment.meetingWith

        doctorsEmail = self.getDoctorEmailViaName(doctorsName=doctorsName)

        # patient
        patientName = attachedAppointment.attachedOwner.username

        patientEmail = attachedAppointment.attachedOwner.email

        # date
        meetingDate = BasicTools().castToTimeZone(attachedAppointment.appointmentDate).strftime('%d, %b, %Y At %I:%M %p')


        # delete the appointment
        attachedAppointment.delete()

        # alert
        AlertTools().sendAlert(recipientUser=self.getDoctorEmailViaName(doctorsName=doctorsName, doctorWanted=True), alertMessage='Your appointment with {} was cancelled'.format(patientName))

        AlertTools().sendAlert(recipientUser=attachedAppointment.attachedOwner, alertMessage='Your appointment with Dr.{} was cancelled'.format(doctorsName))

        AlertTools().sendAlert(recipientUser=ChatTools().getReceptionistAccountUser(), alertMessage='An appointment between Dr.{} and {} was cancelled'.format(doctorsName, patientName))


        # email meta
        mailMeta = {
            'doc_name': doctorsName,
            'doc_email': doctorsEmail,
            'client_name': patientName,
            'client_email': patientEmail,
            'date': meetingDate
        }

        # notify
        NotificationsManager().notifyDoctorAndPatient(emailMeta=mailMeta)

        return doctorsName, patientName, meetingDate

        
    def doctorProfileByName(self, doctorName:str):
        # get the user object of the doctor
        doctorUserInstance = User.objects.filter(username=doctorName).first()

        # get doctors profile
        doctorsProfile:UserProfile = doctorUserInstance.other_details

        return doctorsProfile
    
    def formatApprovedAppointmentsForAdmin(self, appointmentObject:AppointmentItem):
        # names
        clientName = appointmentObject.attachedOwner.username

        doctorName = appointmentObject.meetingWith

        formattedAppointment = {
            'client_name': clientName,
            'doc_name': doctorName,
            # avatars
            'meeting_time': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%I:%M %p'),
            'description': appointmentObject.meetingDescription,
            'type': appointmentObject.meetingType,
            'id': appointmentObject.appointmentId
        }

        
        formattedAppointment['meeting_date'] = BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%d, %b, %Y')

        if appointmentObject.appointmentIsDue() is True:
    
            if appointmentObject.hasPassedAlready(evenNow=True) is True:
                # past today
                formattedAppointment['past'] = True

            else:
                # still active
                formattedAppointment['today'] = True

        else:
            pass



        # load avatars
        # user profile
        clientProfile:UserProfile = appointmentObject.attachedOwner.other_details

        if clientProfile.hasAvatar() is True:
            formattedAppointment['client_avatar'] = clientProfile.userImage

        else:
            formattedAppointment['client_initials'] = BasicTools().generateUserInitials(userName=clientName)

        # doctors profile

        # get doctors profile
        doctorProfile:UserProfile = self.doctorProfileByName(doctorName=doctorName)

        if doctorProfile.hasAvatar() is True:
            formattedAppointment['doctor_avatar'] = doctorProfile.userImage

        else:
            formattedAppointment['doctor_initials'] = BasicTools().generateUserInitials(userName=doctorName)

        return formattedAppointment
    

    def formatUserApprovedAppointments(self, appointmentObject:AppointmentItem, forDoctor:bool=False):
        # format the appointment
        formattedAppointment = {
            'meeting_time':  BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%I:%M %p'),
            'description': appointmentObject.meetingDescription,
            'type': appointmentObject.meetingType,
            'meeting_date': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%d, %b, %Y')
        }

        if forDoctor is False:
            formattedAppointment['doc_name'] = appointmentObject.meetingWith

            formattedAppointment['id'] = appointmentObject.appointmentId

        else:
            formattedAppointment['client_name'] = appointmentObject.attachedOwner.username
        

        if appointmentObject.appointmentIsDue() is True:
    
            if appointmentObject.hasPassedAlready(evenNow=True) is True:
                # past today
                formattedAppointment['past'] = True

            else:
                # still active
                formattedAppointment['today'] = True

        else:
            pass


        # load avatars
        if forDoctor is False:
            # get doctors profile
            doctorProfile:UserProfile = self.doctorProfileByName(doctorName=appointmentObject.meetingWith)

            if doctorProfile.hasAvatar() is True:
                formattedAppointment['doctor_avatar'] = doctorProfile.userImage

            else:
                formattedAppointment['doctor_initials'] = BasicTools().generateUserInitials(userName=appointmentObject.meetingWith)

        else:
            # client user object
            clientUserInstance = appointmentObject.attachedOwner

            # user profile
            clientProfile:UserProfile = clientUserInstance.other_details

            if clientProfile.hasAvatar() is True:
                formattedAppointment['client_avatar'] = clientProfile.userImage

            else:
                formattedAppointment['client_initials'] = BasicTools().generateUserInitials(userName=clientUserInstance.username)


        return formattedAppointment
    


    def formatAppointmentForSimpleCalendar(self, appointmentObject:AppointmentItem):
        # appointment heading
        doctorsName = appointmentObject.meetingWith

        # debug
        # print('Doctor:', doctorsName)

        appointmentType = 'A physical' if appointmentObject.meetingType == 1 else 'An Online'

        meetingTime = BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%I:%M %p')

        descriptionMeta = 'Physically' if appointmentObject.meetingType == 1 else '<a href="{}" target="_blank"><i class="bx bx-link-alt me-1"></i>Goto Meeting</a>'.format(appointmentObject.meetingDescription)
        
        # format the object for calendar view
        formattedAppointmentObject = {
            'id': appointmentObject.appointmentId,
            'name': f'{appointmentType} meeting',
            'date': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%B/%d/%Y'),
            'type': 'event',
            'description': 'Meeting with <strong>Dr.{}</strong> At {} , {}'.format(doctorsName, meetingTime, descriptionMeta),
            'color': '#008900'

        }

        return formattedAppointmentObject
    

    def getUsersActiveAppointments(self, attachedUser:User, formatMethod:int=0):
        approvedAppointments = self.getAllAppointments().filter(hasBeenApproved=True, attachedOwner=attachedUser).all()

        # format object
        executeObjectFormatViaTag = lambda appointmentObject: self.formatUserApprovedAppointments(appointmentObject=appointmentObject) if formatMethod == 0 else self.formatAppointmentForSimpleCalendar(appointmentObject=appointmentObject)

        # format the appointments
        formattedAppointments = [executeObjectFormatViaTag(appointmentObject=eachAppointment) for eachAppointment in approvedAppointments if (eachAppointment.hasPassedAlready(evenNow=True) is False)]

        return formattedAppointments
    
    def getDoctorActiveAppointments(self, doctorsName:User):
        approvedAppointments = self.getAllAppointments().filter(hasBeenApproved=True, meetingWith=doctorsName).all()

        # format the appointments
        formattedAppointments = [self.formatUserApprovedAppointments(appointmentObject=eachAppointment, forDoctor=True) for eachAppointment in approvedAppointments if (eachAppointment.hasPassedAlready(evenNow=True) is False)]

        return formattedAppointments
    


    def loadMyApprovedAppointments(self, attachedDoctor:str, whereToLoad:dict):
        # appointments
        formattedAppointments = self.getDoctorActiveAppointments(doctorsName=attachedDoctor)

        # count
        whereToLoad['approved_valid_count'] = len(formattedAppointments)

        if len(formattedAppointments) > 0:
            whereToLoad['approved_appointments'] = formattedAppointments

        else:
            pass


        return
    
    def loadUserApprovedAppointments(self, attachedUser:User, whereToLoad:dict):
        # appointments
        formattedAppointments = self.getUsersActiveAppointments(attachedUser=attachedUser, formatMethod=0)

        # count
        whereToLoad['approved_valid_count'] = len(formattedAppointments)

        if len(formattedAppointments) > 0:
            whereToLoad['approved_appointments'] = formattedAppointments

        else:
            pass


        return



    def loadAdminApprovedAppointments(self, whereToLoad:dict):
        # get approved appointments
        approvedAppointments = self.getAllAppointments().filter(hasBeenApproved=True).all()

        # debug
        # print("->", approvedAppointments.first().meetingWith)

        formattedAppointments = [self.formatApprovedAppointmentsForAdmin(appointmentObject=eachAppointment) for eachAppointment in approvedAppointments]

        # track valid for today
        validForToday = lambda appointmentObject: 1 if (appointmentObject.hasPassedAlready(evenNow=True) is False) else 0

        # count those valid now
        thoseForToday = sum([validForToday(appointmentObject=eachAppointment) for eachAppointment in approvedAppointments ])

        whereToLoad['those_valid_count'] = thoseForToday

        # print('Formatted Appointments:', formattedAppointments)

        if len(formattedAppointments) > 0:
            whereToLoad['approved_appointments'] = formattedAppointments

        else:
            pass

        return

    
    def getDoctorEmailViaName(self, doctorsName:str, doctorWanted:bool=False):
        # doctor
        doctorWithThatName = User.objects.filter(username=doctorsName).first()

        if doctorWanted is False:
            # email
            responseData = doctorWithThatName.email

        else:
            # user object
            responseData = doctorWithThatName

        return responseData
    
    def processUserNotify(self, appointmentObject:AppointmentItem, userEmail:str, clientName:str):
        # get details
        # doctor-name : Sample Name
        # app - date: 12, Jan, 2024
        # app - time : 2:0 PM
        # meeting type: physical 
        notificationDetails = {
            'doc': appointmentObject.meetingWith,
            'date': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%d, %b, %Y'),
            'time': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%I:%M %p'),
            'method': 'physical' if appointmentObject.meetingType == 1 else 'online',
            'name': clientName
        }

        # debug
        # print('Sent Patient:', notificationDetails)

        # send email
        NotificationsManager().notifyClientOfApproval(
            emailMeta=notificationDetails,
            userEmail=userEmail
        )

        return
    
    def processDoctorNotify(self, doctorsName:str, patientName:str):
        notificationDetails = {
            'name': doctorsName,
            'patient': patientName
        }

        # print('Sent Doctor:', notificationDetails)

        # get doctors email
        doctorsEmail = self.getDoctorEmailViaName(doctorsName=doctorsName)

        # send the email
        NotificationsManager().notifyDoctorOfApproval(emailMeta=notificationDetails, userEmail=doctorsEmail)

        return

    def confirmAppointment(self, approvalMeta:dict):
        # {'appoinment-tag': 'iya8TI5', 'assigned-doctor': 'Penry Hate'}
        doctorName = approvalMeta['assigned-doctor']

        appointmentTag = approvalMeta['appoinment-tag']

        # get the meeting link if its there
        meetingLink = approvalMeta.get('meeting-link', None)

        # make the updates or changes
        foundAppointment = self.getAppointmentById(appointmentId=appointmentTag)

        # get client email
        clientUserInstance = foundAppointment.attachedOwner

        clientEmail = clientUserInstance.email

        clientName = clientUserInstance.username

        # write changes - update approval and doctors name
        foundAppointment.meetingWith = doctorName

        foundAppointment.hasBeenApproved = True

        if not meetingLink is None:
            # write the link too
            foundAppointment.meetingDescription = meetingLink
        
        else:
            pass

        foundAppointment.save()

        # add link between
        ChatTools().addChatContact(
            associatedDoctor=self.getDoctorEmailViaName(doctorsName=doctorName, doctorWanted=True),
            associatedClient=clientUserInstance
        )

        # alert
        AlertTools().sendAlert(recipientUser=clientUserInstance, alertMessage='Check your appointments, you have a newly approved one')

        AlertTools().sendAlert(recipientUser=self.getDoctorEmailViaName(doctorsName=doctorName, doctorWanted=True), alertMessage='You have a new appointment added to your calendar')

        # notify parties
        self.processUserNotify(appointmentObject=foundAppointment, userEmail=clientEmail, clientName=clientName)

        self.processDoctorNotify(doctorsName=doctorName, patientName=clientName)

        return doctorName, clientName


    def adminWipeAppointment(self, appointmentId:str):
        foundAppointment = self.getAppointmentById(appointmentId=appointmentId)

        # owner
        appointmentOwner = foundAppointment.attachedOwner.username

        foundAppointment.delete()

        return appointmentOwner

    def deleteAppointmentRequest(self, attachedUser:User,  appointmentId):
        foundAppointment:AppointmentItem = attachedUser.user_appointments.filter(appointmentId=appointmentId).first()

        # error fail safe
        wasDeleted = False

        # validate
        if foundAppointment:
            # delete it
            foundAppointment.delete()

            # update
            wasDeleted = True

            AlertTools().sendAlert(recipientUser=attachedUser, alertMessage='You deleted your appointment request, you can create another anytime')

        else:
            pass

        return wasDeleted
    
    def loadPendingRequestsForAdmin(self, whereToLoad:dict):
        # get the requests
        allPendingAppointmentRequests = self.getAllAppointments().filter(hasBeenApproved=False).all()

        # get the client details

        # sent: 12-2023-24 At 2:56 AM
        # client name and avatar / initials
        # expiry
        # id : approval and deletion
        # meeting date : 12-23-204 At 2:30 AM
        # contact

        # format each request
        formattedRequests = [self.formatPendingForAdmin(appointmentObject=eachRequest) for eachRequest in allPendingAppointmentRequests]

        # {'sent': '09, Apr, 2024 At 06:16 AM', 'contact': '+256761893534', 'client': 'Mutiibwa Peter', 'status': True, 'id': '4wIXiIKI', 'initials': 'MP'}
        # print(formattedRequests[0])

        whereToLoad['yet_request_count'] = len(formattedRequests)


        if len(formattedRequests) > 0:
            whereToLoad['requests_to_approve'] = formattedRequests

            # debug
            # print('Loaded')
        else:
            pass


        return 


    def isDateDue(self, dateString:str, timeString:str):
        # date object
        # 2024-04-09
        foundDateObject = datetime.strptime(f"{dateString} {timeString}", "%Y-%m-%d %I:%M %p")

        # make it timezone aware
        awareDateAndTime = timezone.make_aware(foundDateObject, timezone.get_current_timezone())

        # get todays aware date and time
        todaysDate = timezone.make_aware(datetime.now(), timezone.get_current_timezone())

        # compare
        dateStatus = awareDateAndTime < todaysDate

        return dateStatus

    def recordNewAppointment(self, appointmentOwner:User, requestMeta:dict):
        # check status
        hasDatePassed = self.isDateDue(
            dateString=requestMeta['meeting-date'],
            timeString=requestMeta['meeting-time']
        )

        if hasDatePassed is False:

            # generate a date time object
            timeStamp:datetime = BasicTools().constructDateTimeObject(
                        dateString=requestMeta['meeting-date'],

                        timeString=requestMeta['meeting-time']
            )
            
            meetingType:int = int(requestMeta['appointment-category'])
            
            otherDetails:str = requestMeta['meeting-particulars'].strip().capitalize()

            meetingId:str = requestMeta['meeting-id']

            # method
            writeMethod = 1 if len(meetingId.strip()) == 0 else 2

            # print('Recorded Date:', timeStamp.strftime("%I:%M %p"))


            if writeMethod == 1:
                # new appointment
                appointmentObject = AppointmentItem.objects.create(
                    attachedOwner=appointmentOwner,
                    appointmentDate=timeStamp,
                    meetingType=meetingType,
                    extraDetails=otherDetails
                )

            else:
                # get the attached object
                appointmentObject:AppointmentItem = appointmentOwner.user_appointments.filter(appointmentId=meetingId).first()

                # update
                appointmentObject.appointmentDate = timeStamp

                appointmentObject.meetingType = meetingType

                appointmentObject.extraDetails = otherDetails

                # mark it as new
                appointmentObject.hasBeenApproved = False
                
            # save
            appointmentObject.save()

        else:
            writeMethod = None

        return writeMethod
    
    def formatPendingForAdmin(self, appointmentObject:AppointmentItem):
        # owner
        requestOwner = appointmentObject.attachedOwner

        # profile
        foundProfile:UserProfile = requestOwner.other_details

        # name
        clientName = requestOwner.username

        formattedRequest = {
            'sent': appointmentObject.createdDate.replace(tzinfo=timezone.get_current_timezone()).strftime("%d, %b, %Y At %I:%M %p"),
            'client': clientName,
            'status': appointmentObject.hasPassedAlready(evenNow=True),
            'id': appointmentObject.appointmentId,
            'contact': "+256{}".format(foundProfile.userContact),
            'when': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime("%d-%m-%Y At %I:%M %p"),
            'how': appointmentObject.meetingType
        }

        if foundProfile.hasAvatar() is True:
            formattedRequest['avatar'] = foundProfile.userImage

        else:
            formattedRequest['initials'] = BasicTools().generateUserInitials(userName=clientName)

        
        return formattedRequest
    


    
    def formatPendingAppointment(self, appointmentObject:AppointmentItem):
        # date: 23, Jan, 2024
        # time: 2:0 PM

        # print('Received:', self.castToTimeZone(appointmentObject.appointmentDate).strftime("%I:%M %p"))

        formattedAppointmentRequest = {
            # 2024-04-09
            'ref_date': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime("%Y-%m-%d"),
            'ref_method': appointmentObject.meetingType,
            'date': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime("%d, %b, %Y"),
            'time': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime("%I:%M %p"),
            'method': {
                1: 'Physical',
                2: 'Online'
            }.get(appointmentObject.meetingType, 'Physical'),
            'details': appointmentObject.extraDetails,
            'id': appointmentObject.appointmentId,
            'expired': appointmentObject.hasPassedAlready()
        }

        return formattedAppointmentRequest


    def loadPendingUserAppointments(self, attachedUser:User, whereToLoad:dict):
        # get pending
        pendingAppointments = AppointmentItem.objects.filter(attachedOwner=attachedUser, hasBeenApproved=False).all()

        # formatted
        formattedRequests = [self.formatPendingAppointment(appointmentObject=eachPendingRequest) for eachPendingRequest in pendingAppointments]

        # validate
        if len(formattedRequests) > 0:
            whereToLoad['pending_appointments'] = formattedRequests

            # print(formattedRequests)

        else:
            pass

        return

    def getAllAppointments(self):
        return AppointmentItem.objects.all()
    
    def formatAppointmentForCalendar(self, appointmentObject:AppointmentItem):
        # format the object for display on the calendar
        formattedEvent = {
            'id': appointmentObject.appointmentId,
            'title': f"{appointmentObject.meetingDescription} - Dr.{appointmentObject.meetingWith}",
            'doctor': appointmentObject.meetingWith,
            'client': appointmentObject.attachedOwner.username,
            'type': 'Physical' if appointmentObject.meetingType == 1 else 'Online',
            'start_time': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%I:%M %p'),
            'meeting_date': BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%b, %d, %Y'),
            "start": BasicTools().castToTimeZone(appointmentObject.appointmentDate).strftime('%Y-%m-%dT%H:%M:%S'),
            'className': ('bg-green' if appointmentObject.meetingType == 1 else 'bg-orange'),
            'description': appointmentObject.meetingDescription,
            'details': appointmentObject.extraDetails,
        }

        return formattedEvent
    
    def sieveAppointmentsInRange(self, startDate:str, endDate:str):
        # 2024-05-12
        castToDateObject = lambda dateString: datetime.strptime(dateString, '%Y-%m-%d').date()

        # get all those in range
        # ['2024-02-19', '2024-02-20', '2024-02-21']
        allDatesWithinRange = TimeTools().generateDatesWithinGap(
            startDate=startDate,
            endDate=endDate
        )

        # ['2024-03-31', '2024-04-01', '2024-04-02', '2024-04-03',
        # print(allDatesWithinRange)
        referenceDates = [castToDateObject(dateString=eachDateItem) for eachDateItem in allDatesWithinRange]

        # print(referenceDates)

        # use reference to get appointments that match
        thoseThatMatch = [eachAppointmentItem for eachAppointmentItem in self.getAllAppointments().filter(hasBeenApproved=True).all() if (eachAppointmentItem.appointmentDate.date() in referenceDates)]

        # format each of the appointments
        formattedAppointments = [self.formatAppointmentForCalendar(appointmentObject=eachMatchingAppointment) for eachMatchingAppointment in thoseThatMatch]

        return formattedAppointments

class Authenticator:
    def loadAvailableContact(self, whereToLoad:dict):
        # get the contact
        adminContact = ContactTools().getAdminContact()

        whereToLoad['our_contact'] = adminContact

        return

    def alterIfOldKeyMatches(self, userObject:User, claimedOld:str, newKey:str):
        # validate
        oldKeyMatches = userObject.check_password(raw_password=claimedOld)

        # debug
        updateMade = False

        if oldKeyMatches is True:
            # update
            userObject.set_password(raw_password=newKey)

            # write changes
            userObject.save()

            updateMade = True

            AlertTools().sendAlert(recipientUser=userObject, alertMessage='You changed your password to this account')

        else:
            # invalid
            pass

        return updateMade
    

    def wipeUserAccount(self, profileTag:str, wipeState:int):
        # get the user attached to that tag
        foundProfile = FetchTools().getProfileViaTag(
            profileTag=profileTag
        )

        # get the user object
        attachedUser = foundProfile.userInstance

        # get the name
        userName = attachedUser.username

        if wipeState == 0:
            userEmail = attachedUser.email

            # wipe the account
            attachedUser.delete()


            # alert deletion status
            NotificationsManager().pushSorryMessage(
                userName=userName,
                userEmail=userEmail
            )

            responseMessage = f'Hey {userName} you account was deleted from our website, we sorry 😥 about any dismay we may have caused'


        else:
            # verify and see if teh doctor has appointments already
            hasAppointments = AppointmentItem.objects.filter(meetingWith=userName).count()

            if hasAppointments == 0:
                attachedUser.delete()

                responseMessage = f'Access for {userName} was revoked successfully 😏'

            else:
                # alert error
                responseMessage = None
                

        return responseMessage
    
    

    def userHasProfile(self, userObject:User):
        # receptionist
        statusTag = 2

        # check if such a profile exists
        foundProfile = UserProfile.objects.filter(userInstance=userObject).first()

        if foundProfile:
            statusTag = foundProfile.statusTag

        else:
            pass

        return statusTag

    def userExistsAlready(self, userEmail:str):
        # count how many users have such an email
        userCount = User.objects.filter(email=userEmail).count()

        # status
        isDuplicate = userCount > 0

        return isDuplicate
    
    def userNameTaken(self, firstName:str, lastName:str):
        # merge the names into one
        mergedName = "{} {}".format(firstName.strip().capitalize(), lastName.strip().capitalize())

        # count how many users have such an email
        userCount = User.objects.filter(username=mergedName).count()

        # status
        nameTakenAlready = userCount > 0

        return nameTakenAlready


    def draftUserInstance(self, userFirstName:str, userLastName:str, userEmail:str, userPassword:str):
        # user object
        userName = f"{userFirstName} {userLastName}"

        userObject = User.objects.create(username=userName, email=userEmail, first_name=userFirstName, last_name=userLastName)

        # add password
        userObject.set_password(raw_password=userPassword)

        userObject.save()

        return userObject
    
    
    def validateUserCredentials(self, credentialsObject:dict):
        # get the email
        submittedEmail = credentialsObject['email']

        # user object
        userDetail = User.objects.filter(email=submittedEmail).first()

        passwordsMatch = None

        if userDetail:
            # passwords match
            passwordsMatch = userDetail.check_password(credentialsObject['password'])

        else:
            pass

        return passwordsMatch, userDetail


    
    def writeNewUserProfile(self, attachedUser:User, userContact:str, statusTag:int, userRole:str=None, isVerified:bool=False):
        newProfile = UserProfile.objects.create(
            userInstance=attachedUser,
            userContact=('' if userContact is None else userContact),
            statusTag=statusTag,
            userRole=('' if userRole is None else userRole),
            isVerified=isVerified
        )

        newProfile.save()

        return

        
    def writeNewClientUser(self, userDetails:dict):
        # get the user details from request
        attachedUserObject = self.draftUserInstance(
            userFirstName=userDetails['first-name'].strip().capitalize(),
            userLastName=userDetails['last-name'].strip().capitalize(),
            userEmail=userDetails['email'],
            userPassword=userDetails['confirm-password']
        )

        # client contact


        # create a profile
        clientContact = userDetails['telephone']


        self.writeNewUserProfile(
            attachedUser=attachedUserObject,
            userContact=clientContact,
            statusTag=0,
            userRole=None,
            isVerified=False
        )

        # customer image
        self.monitorCustomerImage(attachedUser=attachedUserObject, userContact=clientContact)

        return
    
    def monitorCustomerImage(self, attachedUser:User, userContact:str):
        # check if customer exists already
        clientObject = CustomerDetails.objects.filter(attachedOwner=attachedUser).first()

        if clientObject:
            clientObject.clientContact = userContact

            clientObject.save()

        else:
            # create new customer image
            customerDetailObject = CustomerDetails.objects.create(
                attachedOwner=attachedUser,
                clientName=attachedUser.username,
                clientContact=userContact
            )

            customerDetailObject.save()

        return
    
    def generateRandomPasswords(self):
        return secrets.token_urlsafe(5)

    def writeNewStaff(self, userDetails:dict):
        # generate a temporary password
        temporaryPassword = self.generateRandomPasswords()

        # get the user details from request
        attachedUserObject = self.draftUserInstance(
            userFirstName=userDetails['first-name'].strip().capitalize(),
            userLastName=userDetails['last-name'].strip().capitalize(),
            userEmail=userDetails['email'],
            userPassword=temporaryPassword
        )

        # create a profile
        self.writeNewUserProfile(
            attachedUser=attachedUserObject,
            userContact=None,
            statusTag=1,
            userRole=userDetails['attached-role'].strip().title(),
            isVerified=True
        )

        # name
        staffName = attachedUserObject.username

        # send an email to the person
        NotificationsManager().notifyStaffOfAccessGrant(
            staffName=staffName,
            emailAddress=attachedUserObject.email,
            temporaryPassword=temporaryPassword
        )

        return staffName

        
    def determineUserStatus(self, emailToValidate:str):
        # check for reference
        userWithThatEmail = User.objects.filter(email=emailToValidate).first()

        if userWithThatEmail is None:
            responseTag = -1

        else:
            # 0 - staff member i.e admin and doctors, 1 - client has account
            responseTag = 0 if userWithThatEmail.other_details.statusTag in [1, 2] else 1

        return responseTag
        


