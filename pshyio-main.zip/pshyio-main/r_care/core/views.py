from django.shortcuts import render, redirect

from django.views.decorators.cache import cache_control

from .siteTools import (
    Authenticator, AppointmentTools, 
    VerificationTools, ResetTools, 
    FetchTools, BasicTools,
    MessageTools, ContactTools, ReportTools,
    ExportUtilities, ChatTools, AlertTools
)

from django.contrib.auth import login, logout

from django.contrib.auth.decorators import login_required, user_passes_test

from django.contrib.auth.models import User

from django.http import HttpRequest, JsonResponse

from django.contrib import messages

from datetime import datetime


def executeSignIn(userObject:User, requestObject:HttpRequest):
    login(requestObject, userObject)

    return

def custom_404(request, exception):
    return render(request, 'core/404.html', status=404)


@login_required(login_url='hive:login')
@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def determineRedirectRoute(request):
    # by default its the admin dashboard
    statusTag = request.session['details']['status']

    # default - client
    homeUrl = 'hive:dashboard'

    if statusTag == 1:
        # doctor
        homeUrl = 'hive:doc-dash'

    elif statusTag == 2:
        # admin
        homeUrl = 'hive:base'

    else:
        pass

    return redirect(homeUrl)

def cacheUserStatus(attachedUser:User, requestObject:HttpRequest):
    # check if user has a profile
    statusTag = Authenticator().userHasProfile(userObject=attachedUser)

    # session data
    sessionData = {
        'status': statusTag,
        'id': attachedUser.pk,
    }

    if statusTag == 2:
        userContact = ContactTools().getAdminContact()

    else:
        userContact = ContactTools().getUserContact(userObject=attachedUser)

    # load the contact
    sessionData['contact'] = userContact

    # store the status
    requestObject.session['details'] = sessionData

    return
    


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
def logoutUser(request):
    logout(request=request)

    return redirect('hive:login')

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def validateSignIn(request):
    # credentials
    submittedCredentials = request.POST.dict()

    # validate credentials
    passwordState, userObject = Authenticator().validateUserCredentials(
        credentialsObject=submittedCredentials
    )

    # default redirect is back to login
    redirectString = 'hive:login'

    if passwordState is None:
        messages.error(request, "No such account exists")

    elif passwordState is False:
        messages.warning(request, "Either the email or password is invalid")

    else:
        # login the user
        executeSignIn(
            userObject=userObject,
            requestObject=request
        )

        # discard any password reset links if any
        # if user asked for a reset link but remembered their password now
        ResetTools().discardAnyResetLinks(userEmail=userObject.email)

        # store the user status
        cacheUserStatus(attachedUser=userObject, requestObject=request)

        # load avatar
        BasicTools().loadUserAvatar(
            requestObject=request
        )


        return redirect('hive:resolve')


    return redirect(redirectString)


def clientIsVerified(userInstance:User):
    return (userInstance.other_details.isVerified is True)

def clientNotVerified(userInstance:User):
    return (userInstance.other_details.isVerified is False)

def isClient(userInstance:User):
    # logged in and is client
    return userInstance.is_authenticated and (Authenticator().userHasProfile(userObject=userInstance) == 0)

def isDoctor(userInstance:User):
    # logged in and is client
    return userInstance.is_authenticated and (Authenticator().userHasProfile(userObject=userInstance) == 1)

def isAdmin(userInstance:User):
    # logged in and is client
    return userInstance.is_authenticated and (Authenticator().userHasProfile(userObject=userInstance) == 2)

def adminOrClient(userInstance:User):
    return isClient(userInstance=userInstance) or isAdmin(userInstance=userInstance)

def doctorOrClient(userInstance:User):
    return isClient(userInstance=userInstance) or isDoctor(userInstance=userInstance)


def allowedToSendMessages(userInstance:User):
    return isAdmin(userInstance=userInstance) or isDoctor(userInstance=userInstance) or clientIsVerified(userInstance=userInstance)


def notAuthenticated(userInstance:User):
    return userInstance.is_anonymous




def displayHiveHomePage(request):
    mainHomeContext = {}

    Authenticator().loadAvailableContact(whereToLoad=mainHomeContext)

    return render(request, "core/index.html", context=mainHomeContext)


def displayHiveAboutPage(request):
    mainAboutContext = {}

    Authenticator().loadAvailableContact(whereToLoad=mainAboutContext)

    return render(request, "core/about.html", context=mainAboutContext)


def displayHiveContactPage(request):
    mainContactContext = {}

    Authenticator().loadAvailableContact(whereToLoad=mainContactContext)

    return render(request, "core/contact.html", context=mainContactContext)



@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@user_passes_test(notAuthenticated, login_url='hive:resolve')
def requestResetLink(request):
    # receive the reset email
    resetMeta = request.POST.dict()

    # extract the reset email
    resetEmail = resetMeta['reset-email']

    # validate email
    userExists, attachedUser = ResetTools().userExistsViaEmail(claimingEmail=resetEmail)

    if userExists is True:
        # issue a reset link now
        ResetTools().issueResentLink(
            userObject=attachedUser
        )

        messages.info(request, 'We sent a confirmation reset link to your email inbox, open it and do as instructed')

    else:
        # check if link was issued

        messages.warning(request, 'It appears like no such account exists, recheck the provided email address')

    
    return redirect('hive:login')


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@user_passes_test(notAuthenticated, login_url='hive:resolve')
def acknowledgeReset(request:HttpRequest, resetCode:str):
    # check if the code is valid
    codeIsValid, ownerEmail = ResetTools().resetCodeIsValid(
        resetCode=resetCode
    )

    if codeIsValid is True:
        # write the verification
        ResetTools().executePasswordReset(
            userEmail=ownerEmail
        )

        messages.success(request, 'Check your inbox we just issued you a temporary password, you can then login here 👇')

    else:
        # error
        messages.warning(request, 'It appears like you have a broken reset link, generate a new one at forgot password')

    # back to login
    redirectUrl = 'hive:login'

    return redirect(redirectUrl)

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def verifyUserEmail(request:HttpRequest, linkCode:str):
    # check if the code is valid
    linkIsValid = VerificationTools().isCodeValid(linkCode=linkCode)

    if linkIsValid is True:
        # write the verification
        VerificationTools().recordTheVerification(
            linkId=linkCode
        )        

        if request.user.is_authenticated:
            # verification was successful
            messages.success(request, 'Your email was successfully verified')

            redirectUrl = 'hive:resolve'

        else:
            # alert login
            messages.success(request, 'Your email was successfully verified, you can login and manage your work flows')

            redirectUrl = 'hive:login'
    else:
        # check if the user is authenticated
        if request.user.is_authenticated:
            # verify them if they are clients and not verified
            redirectUrl = 'hive:verify-notice'

        else:
            redirectUrl = 'hive:home'

    return redirect(redirectUrl)


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def displayClientSignup(request):
    signupContext = {
        'at_signup': True
    }

    return render(request, "core/sign-up.html", context=signupContext)

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def displayAppointmentPage(request):
    if request.user.is_authenticated:
        return redirect('hive:dashboard')
    
    else:
        pass

    pageContext = {
        'at_appointment': True
    }
    
    return render(request, "core/appointment.html", context=pageContext)

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def displayLoginPage(request):
    if request.user.is_authenticated:
        return redirect('hive:resolve')
    
    else:
        pass

    loginContext = {
        'at_login_page': True
    }

    return render(request, "core/login.html", context=loginContext)



@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
def processAppointmentRequest(request):
    # get the details
    appointmentMeta = request.POST.dict()

    # save the appointment
    writeOperation = AppointmentTools().recordNewAppointment(
        appointmentOwner=request.user,
        requestMeta=appointmentMeta
    )

    if writeOperation is None:
        messages.warning(request, 'Consider checking your date of the appointment it appears like its past')

    else:
        if writeOperation == 1:
            displayMessage = 'Your appointment request has been received successfully, you will be notified when its approved.'

        else:
            displayMessage = 'Your changes to the appointment request where saved successfully'

        
        AlertTools().sendAlert(recipientUser=request.user, alertMessage=displayMessage)

        messages.success(request, displayMessage)

    return redirect(request.META['HTTP_REFERER'])




@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def registerNewClientUser(request):
    # register user details
    submittedData = request.POST.dict()

    # back to signup on failure
    redirectString = 'hive:signup'


    # username take
    userNameTaken = Authenticator().userNameTaken(
        firstName=submittedData['first-name'],
        lastName=submittedData['last-name'],
    )

    if userNameTaken is False:
        # determine if user is a duplicate
        emailWasTaken = Authenticator().userExistsAlready(submittedData['email'])

        if emailWasTaken is False:
            # write details of the client user
            Authenticator().writeNewClientUser(userDetails=submittedData)

            redirectString = 'hive:login'

            messages.success(request, "Your account was created, sign in now!")
            
        else:
            messages.warning(request, 'An account with such credentials exists already, consider logging in.')

    else:
        messages.warning(request, "Ohh sorry 😥, It appears like that user name is already taken, you may need to change the first or last name")

    # goto the user account
    return redirect(redirectString)


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
@user_passes_test(clientNotVerified, login_url='hive:resolve')
def sendVerificationLinkAgain(request:HttpRequest):
    # send the link again
    VerificationTools().issueNewVerificationLink(userObject=request.user)

    print('I reachede here')

    return JsonResponse(
        {
            'status': 'ok'
        }
    )


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
@user_passes_test(clientNotVerified, login_url='hive:resolve')
def executeReverifyRoutine(request):
    # validate
    usersEmail = request.user.email

    # get state
    linkSentStatus = VerificationTools().linkSentAlready(userEmail=usersEmail)

    # delete any links
    if linkSentStatus is True:
        VerificationTools().deleteAnyExistingLinks(userEmail=usersEmail)

    else:
        pass

    return redirect('hive:verify-notice')


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
@user_passes_test(clientNotVerified, login_url='hive:resolve')
def initiateEmailVerification(request:HttpRequest):
    resetContext = {}

    # email
    usersEmail = request.user.email

    # get state
    linkSentStatus = VerificationTools().linkSentAlready(userEmail=usersEmail)


    if (linkSentStatus is False):
        resetContext['reset_client'] = request.user.email

        messages.success(request, 'A verification link is being sent to your email, check your inbox and verify your email 😌')

    else:
        messages.info(request, 'A verification is already sent to your email, if you lost the email, please request a new one 😌')

    return render(request, "core/barrier.html", context=resetContext)


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
@user_passes_test(clientIsVerified, login_url='hive:verify-notice')
def displayUserAccount(request):
    dashBoardContext = {

    }

    # load pending
    AppointmentTools().loadPendingUserAppointments(
        attachedUser=request.user,
        whereToLoad=dashBoardContext
    )

    # approved meetings
    AppointmentTools().loadUserApprovedAppointments(
        attachedUser=request.user,
        whereToLoad=dashBoardContext
    )

    loadingFor = messagesLoader(requestObject=request, whereToLoad=dashBoardContext)

    # debug
    # print('Passed here:')

    ChatTools().loadUserContacts(requestObject=request, whereToLoad=dashBoardContext, whoseChats=loadingFor)


    AlertTools().loadMyAlerts(attachedUser=request.user, whereToLoad=dashBoardContext)

    return render(request, "core/user-account.html", context=dashBoardContext)


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
@user_passes_test(clientIsVerified, login_url='hive:verify-notice')
def executeAppointmentCancellation(request, appointmentId:str):
    # get the appointment
    executionStatus = AppointmentTools().deleteAppointmentRequest(
        attachedUser=request.user,
        appointmentId=appointmentId
    )

    if executionStatus is True:
        messages.success(request, "Your appointment request was withdrawn and deleted successfully")

    else:
        messages.warning(request, "It appears like you followed a broken link")

    return redirect(request.META['HTTP_REFERER'])


def messagesLoader(requestObject:HttpRequest, whereToLoad:dict):
    # check for details
    whoseMessages = requestObject.session.get('load_from', None)

    if whoseMessages:
        # debug
        # print('Load Messages from:', whoseMessages)

        # load the messages
        ChatTools().getChatsWith(requestObject=requestObject, fromTag=whoseMessages, whereToLoad=whereToLoad)

    else:
        pass

    return whoseMessages


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def displayAdminHome(request):
    adminHomeContext = {
        'admin_page': True
    }

    MessageTools().loadContactMessagesAndCount(
        whereToLoad=adminHomeContext
    )

    # load approved appointments
    AppointmentTools().loadAdminApprovedAppointments(whereToLoad=adminHomeContext)

    # pending appointments
    AppointmentTools().loadPendingRequestsForAdmin(whereToLoad=adminHomeContext)

    # print(adminHomeContext)
    FetchTools().loadStaffList(whereToLoad=adminHomeContext)

    # load messages if so
    loadingFor = messagesLoader(requestObject=request, whereToLoad=adminHomeContext)

    # chat contacts
    ChatTools().loadUserContacts(requestObject=request, whereToLoad=adminHomeContext, whoseChats=loadingFor)

    AlertTools().loadMyAlerts(attachedUser=request.user, whereToLoad=adminHomeContext)

    # debug
    # print("Time:", datetime.now())

    return render(request, "core/admin-dash.html", context=adminHomeContext)



@user_passes_test(isAdmin, login_url='hive:login')
@login_required(login_url='hive:login')
@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def getCalendarEvents(request):
    # ?start=2024-01-28&end=2024-03-10
    # get the range that is required
    startDate = request.GET.get("start", None)

    endDate = request.GET.get("end", None)

    # Start: 2024-03-31  End: 2024-05-12
    # print('Start:', startDate, " End:", endDate)

    # validate
    if startDate is None or endDate is None:
        foundMatches = []

    else:
        # see all events in that range
        foundMatches = AppointmentTools().sieveAppointmentsInRange(
            startDate=startDate,
            endDate=endDate
        )

        # time stamp format: '2024-02-11T11:00:00'
        # sampleEvent = {
        #     'id': 'xg562hT',
        #     'title': 'knee Checkup - Dr.Peter',
        #     'doctor': 'Peter Mercy',
        #     'client': 'Joyce Joel',
        #     'type': 'Online',
        #     'start_time': '12:60 PM',
        #     'meeting_date': '13-36-2024',
        #     "start": '2024-04-01T11:00:00',
        #     'className': 'bg-success',
        #     'description': 'Knee checkup',
        #     'details': 'I feel a lot of pain'
        # }

        # debug event
        # foundMatches += [sampleEvent]

        # print(foundMatches) 

    return JsonResponse(foundMatches, safe=False)



@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def displayUserList(request):
    userContext = {
        'at_user_list': True
    }

    MessageTools().loadContactMessagesAndCount(
        whereToLoad=userContext
    )



    # load staff members
    FetchTools().loadAvailableStaff(
        whereToLoad=userContext
    )

    return render(request, "core/admin-users.html", context=userContext)



@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isDoctor, login_url='hive:resolve')
def displayDoctorsPanel(request):
    doctorContext = {

    }

    # approved meetings
    AppointmentTools().loadMyApprovedAppointments(
        attachedDoctor=request.user.username,
        whereToLoad=doctorContext
    )

    # load messages if so
    loadingFor = messagesLoader(requestObject=request, whereToLoad=doctorContext)

    # chat contacts
    ChatTools().loadUserContacts(requestObject=request, whereToLoad=doctorContext, whoseChats=loadingFor)

    # alerts
    AlertTools().loadMyAlerts(attachedUser=request.user, whereToLoad=doctorContext)

    # load history
    AppointmentTools().loadWorkingHistory(doctorUserObject=request.user, whereToLoad=doctorContext)

    return render(request, "core/doctor-account.html", context=doctorContext)

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def registerNewStaff(request):
    # register user details
    submittedData = request.POST.dict()

    # validate if the user name is not taken yet
    userNameTaken = Authenticator().userNameTaken(
        firstName=submittedData['first-name'],
        lastName=submittedData['last-name'],
    )

    if userNameTaken is False:

        # determine if user is a duplicate
        emailWasTaken = Authenticator().userExistsAlready(submittedData['email'])


        if emailWasTaken is False:
            # write details of the client user
            addedUser = Authenticator().writeNewStaff(userDetails=submittedData)

            # debug
            # addedUser = 'Peter'

            messages.success(request, f"A new user {addedUser} was registered successfully")
            
        else:
            messages.warning(request, 'A staff member with that email exists already')

    else:
        # alert
        messages.warning(request, "That username seems already taken among system users, i advise you change either the first or last name")

    # goto the user account
    return redirect(request.META['HTTP_REFERER'])


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(adminOrClient, login_url='hive:resolve')
def deleteUserAccount(request):
    # meta
    profileMeta = request.POST.dict()

    # get the profile id
    profileId = profileMeta['p-tag']

    wipeState = int(profileMeta['state'])

    # pass
    displayMessage = Authenticator().wipeUserAccount(
        profileTag=profileId,
        wipeState=wipeState
    )

    if displayMessage is None:
        messages.warning(request, "The Staff member has appointments attached, first resolve them to 0 (maybe cancel them) and try again")
    
        redirectUrl = request.META['HTTP_REFERER']
        
    else:
        # alert
        messages.success(request, displayMessage)

        if wipeState == 0:
            # back to login page
            redirectUrl = 'hive:login'

        else:
            # back to account
            redirectUrl = request.META['HTTP_REFERER']

            AlertTools().sendAlert(recipientUser=request.user, alertMessage='You revoked access of a fellow staff member')

    return redirect(redirectUrl)

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
def alterAccountPassword(request):
    # meta
    newMeta = request.POST.dict()

    updateState = Authenticator().alterIfOldKeyMatches(
        userObject=request.user,
        claimedOld=newMeta['current-password'],
        newKey=newMeta['confirm-password'],
    )

    if updateState is True:
        messages.success(request, "Your password was changed successfully, you can login again please")

        redirectUrl = 'hive:login'

    else:
        messages.warning(request, "It appears as though the provided password never matches the current one")

        redirectUrl = request.META['HTTP_REFERER']

    return redirect(redirectUrl)


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(doctorOrClient, login_url='hive:resolve')
def changeAvatar(request):
    # get the avatar
    avatarMeta = request.POST.dict()

    # debug
    # print(avatarMeta)

    # make the update
    BasicTools().updateUserAvatar(
        requestObject=request,
        newAvatar=avatarMeta['avatar']
    )

    # alert
    messages.success(request, 'Your profile image was updated successfully!')

    return redirect(request.META['HTTP_REFERER'])


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
def receiveSentMessage(request):
    # meta
    messageMeta = request.POST.dict()

    # save the message
    MessageTools().createMessageItem(messageMeta=messageMeta)

    # alert
    messages.success(request, 'Your message was received successfully, we shall get be getting back to you')

    return redirect(request.META['HTTP_REFERER'])


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def executeSeenWhisper(request):
    # cleanup everything: mark all seen
    MessageTools().makeMessagesSeen()

    return JsonResponse(
        {
            'status': 'ok'
        }
    )

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def dumpContactMessage(request):
    # get the data
    messageMeta = request.POST.dict()

    # debug
    # {'msg_tag': 'yUuldho7'}
    # print("Received:", messageMeta)

    # delete the message
    MessageTools().wipeMessageItem(
        messageMeta=messageMeta
    )


    return JsonResponse(
        {
            'status': 'ok'
        }
    )


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def wipeAllMessages(request):
    # delete all messages
    MessageTools().cleanUpContactMessages()

    # alert
    messages.success(request, 'You just wiped all contact messages')

    AlertTools().sendAlert(recipientUser=request.user, alertMessage='You deleted all messages submitted via the website contact form')

    return redirect(request.META['HTTP_REFERER'])

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
def updateContactInformation(request):
    # get info
    contactMeta = request.POST.dict()

    # make update
    displayMessage = ContactTools().alterContactInformation(contactMeta=contactMeta, requestObject=request)

    messages.success(request, displayMessage)

    return redirect(request.META['HTTP_REFERER'])


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
@user_passes_test(clientIsVerified, login_url='hive:verify-notice')
def displayAllPatientAppointments(request):
    return render(request, "core/appointments.html")

@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def executeAppointmentWipe(request):
    # meta
    appointmentMeta = request.POST.dict()

    # get the id
    appointmentId = appointmentMeta['appointment-id']

    # wipe
    ownerOfAppointment = AppointmentTools().adminWipeAppointment(
        appointmentId=appointmentId
    )

    messages.success(request, f"An appointment submitted by {ownerOfAppointment} was dumped, please inform them of the changes")

    return redirect(request.META['HTTP_REFERER'])


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def approveAppointmentRequest(request):
    # meta
    approvalMeta = request.POST.dict()

    # print(approvalMeta)

    # confirm
    doctorsName, patientName = AppointmentTools().confirmAppointment(
        approvalMeta=approvalMeta
    )

    messages.success(request, f"An appointment was approved for Dr.{doctorsName} and {patientName}")

    return redirect(request.META['HTTP_REFERER'])


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def cancelAppointmentAndNotify(request):
    # meta
    cancellationMeta = request.POST.dict()

    # get the id
    appointmentId = cancellationMeta['appointment-tag']

    # print('tag:', appointmentId)

    # cancel
    doctorsName, patientName, meetingDate = AppointmentTools().executeCancelAndNotify(appointmentId=appointmentId)

    messages.success(request, f"The appointment between Dr.{doctorsName} and {patientName} dated {meetingDate} has been cancelled")

    return redirect(request.META['HTTP_REFERER'])



@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def markAppointmentAsComplete(request):
    # meta
    completedMeta = request.POST.dict()

    # get the id
    appointmentId = completedMeta['appointment-tag']

    # print('tag:', appointmentId)

    # cancel
    doctorsName, dateOfAppointment = AppointmentTools().writeNewHistoryItem(
        appointmentId=appointmentId
    )

    messages.success(request, f"An appointment for Dr.{doctorsName} dated for {dateOfAppointment} was marked completed, it will now only appear in their history")

    return redirect(request.META['HTTP_REFERER'])


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
@user_passes_test(clientIsVerified, login_url='hive:verify-notice')
def cancelMyAppointment(request):
    # meta
    cancellationMeta = request.POST.dict()

    # get the id
    appointmentId = cancellationMeta['appointment-tag']

    # print('tag:', appointmentId)

    # cancel
    doctorsName, _, meetingDate = AppointmentTools().executeCancelAndNotify(appointmentId=appointmentId)

    messages.success(request, f"Your appointment with Dr.{doctorsName} dated {meetingDate} has been cancelled")

    return redirect(request.META['HTTP_REFERER'])


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isClient, login_url='hive:resolve')
@user_passes_test(clientIsVerified, login_url='hive:verify-notice')
def fetchMyAppointments(request):
    # get the user details
    foundDetails = AppointmentTools().getUsersActiveAppointments(attachedUser=request.user, formatMethod=1)

    # debug
    print(foundDetails)

    return JsonResponse({
        'info': foundDetails
    }, safe=False)


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def viewReportsPage(request):
    reportsContext = {

    }

    # load
    ReportTools().loadClientList(whereToLoad=reportsContext)


    return render(request, "core/reports.html", context=reportsContext)


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(isAdmin, login_url='hive:resolve')
def exportCustomerList(request):
    # export
    exportTedDataResponse = ExportUtilities().dumpCustomerList()

    # debug
    # print("Found:", exportTedDataResponse is None)

    if exportTedDataResponse is None:
        # response
        responseObject = redirect(request.META['HTTP_REFERER'])

        messages.success(request, "There are customers registered yet 😌")

    else:
        responseObject = exportTedDataResponse

    return responseObject


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(allowedToSendMessages, login_url='hive:resolve')
def loadChatMessages(request, fromTag:str):
    # determine if the contact is a valid one
    isContactValid = ChatTools().chatContactExists(requestObject=request, contactTag=fromTag)


    # debug
    # print('Status:', isContactValid)

    if isContactValid is True:
        # store the from tag
        request.session['load_from'] = fromTag

        request.session.modified = True

        # load chats
        responseObject = redirect(request.META['HTTP_REFERER'])

        # print('Reached inside here')

    else:
        responseObject = redirect(request.META.get('HTTP_REFERER', 'hive:resolve'))


    return responseObject


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(allowedToSendMessages, login_url='hive:resolve')
def pushChatMessage(request):
    # pass
    messageMeta = request.POST.dict()

    toWhoTag = messageMeta['to-who-tag']

    toWhoName = messageMeta['to-who-name']

    # alert
    messageContent = messageMeta['message-content'].strip()

    # write the message
    ChatTools().recordChatMessage(senderUserObject=request.user, toWhoTag=toWhoTag, messageContent=messageContent)

    messages.success(request, f"Your message to {toWhoName} was sent successfully!")

    return redirect(request.META['HTTP_REFERER'], fromTag=toWhoTag)



@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
@user_passes_test(allowedToSendMessages, login_url='hive:resolve')
def deleteSelectedMessage(request, messageTag:str, fromTag:str):
    # delete that message
    deletionStatus = ChatTools().deleteChatMessage(chatMessageTag=messageTag)

    # redirect back to the messages tag
    if deletionStatus is True:
        messages.debug(request, f"You just wiped a message")

    else:
        pass

    return redirect(request.META['HTTP_REFERER'], fromTag=fromTag)


@cache_control(no_store=True, no_cache=True, must_revalidate=True)
@login_required(login_url='hive:login')
def wipeMyAlerts(request):

    # wipe
    AlertTools().deleteAttachedAlerts(userObject=request.user)

    messages.success(request, "All your alerts were wiped successfully")

    return redirect(request.META['HTTP_REFERER'])










