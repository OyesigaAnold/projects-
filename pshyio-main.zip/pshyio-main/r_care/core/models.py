from django.db import models

from django.contrib.auth.models import User

from datetime import datetime, date

from django.utils import timezone

import secrets

def generateItemId():
    return secrets.token_urlsafe(6)

def timeZoneLocalTime():
    currentTime = timezone.now()

    # Convert the current time to the desired timezone
    currentLocalTime = currentTime.astimezone(timezone.get_current_timezone())

    return currentLocalTime

def changeToTimeZone(dateTimeObject:datetime):
    # Convert the current time to the desired timezone
    changedTimeZoneDate = dateTimeObject.astimezone(timezone.get_current_timezone())

    return changedTimeZoneDate

class ChatMessage(models.Model):
    createdDate = models.DateTimeField(default=timeZoneLocalTime)

    messageId = models.TextField(default=generateItemId)

    toWho = models.ForeignKey(User, on_delete=models.CASCADE, related_name='my_outbox')

    fromWho = models.ForeignKey(User, on_delete=models.CASCADE, related_name='my_inbox')

    messageContent = models.TextField()

    involvesAdmin = models.BooleanField(default=True)

    toSeen = models.BooleanField(default=False)


class ChatContact(models.Model):
    contactId = models.TextField(default=generateItemId)

    associatedUser = models.ForeignKey(User, on_delete=models.CASCADE, related_name='my_doctors')

    contactDetail = models.ForeignKey(User, on_delete=models.CASCADE, related_name='my_patients')


class NotificationAlertItem(models.Model):
    sentDate = models.DateTimeField(default=timeZoneLocalTime)

    notificationId = models.TextField(default=generateItemId)

    associatedUser = models.ForeignKey(User, on_delete=models.CASCADE, related_name='my_notifications')

    attachedMessage = models.TextField()

    class Meta:
        ordering = ("-sentDate",)


    def alertForToday(self):
        # get todays date
        currentDate = changeToTimeZone(dateTimeObject=datetime.now()).date()

        # check
        sentToday = (currentDate == self.sentDate.date())

        return sentToday


class HistoryItem(models.Model):
    createdDate = models.DateTimeField(default=timeZoneLocalTime)

    historyItemId = models.TextField()

    attachedDoctor = models.ForeignKey(User, on_delete=models.CASCADE, related_name='my_history')

    patientMetWith = models.TextField()

    timeAndDate = models.TextField()

    meetingMethod = models.TextField()




class ResetLink(models.Model):
    resetId = models.TextField(default=generateItemId)

    ownerEmail = models.TextField()


class AdminContact(models.Model):
    companyContact = models.TextField(default='no-contact')


class MessageItem(models.Model):
    dateSent = models.DateTimeField(default=timeZoneLocalTime)

    messageId = models.TextField(default=generateItemId)

    senderName = models.TextField()    

    senderEmail = models.TextField() 

    senderContact = models.TextField()

    sentMessage = models.TextField()

    messageSeen = models.BooleanField(default=False)


    class Meta:
        ordering = ("-dateSent",)


class CustomerDetails(models.Model):
    attachedOwner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="customer_detail")

    clientName = models.TextField()

    clientContact = models.TextField()




class UserProfile(models.Model):
    userId = models.TextField(default=generateItemId)

    userInstance = models.OneToOneField(User, on_delete=models.CASCADE, related_name='other_details', null=True)

    userContact = models.TextField(default='')

    userImage = models.TextField(default='')

    userRole = models.TextField(default='')

    # 0 - client, 1 - doctors, 2 - admin
    statusTag = models.IntegerField(default=0)

    isVerified = models.BooleanField(default=False)

    def getUserContact(self):
        # validate
        contactDetail = self.userContact if len(self.userContact.strip()) > 0 else 'Missing'

        return contactDetail


    def hasAvatar(self):
        # avatar check
        avatarPresent = len(self.userImage.strip()) > 0

        return avatarPresent


class VerificationLink(models.Model):
    itemId = models.TextField(default=generateItemId)

    attachedUserEmail = models.TextField()

    profileTag = models.TextField()


class AppointmentItem(models.Model):
    appointmentId = models.TextField(default=generateItemId)

    createdDate = models.DateTimeField(default=timeZoneLocalTime)

    attachedOwner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_appointments')

    isSatisFied = models.BooleanField(default=False)

    hasBeenApproved = models.BooleanField(default=False)

    appointmentDate = models.DateTimeField()

    meetingType = models.IntegerField()

    extraDetails = models.TextField()

    meetingWith = models.TextField(default='')

    meetingDescription = models.TextField(default='Physical Meeting')

    class Meta:
        ordering = ("-createdDate",)


    def appointmentIsDue(self):
        # get todays date
        currentDateObject = changeToTimeZone(dateTimeObject=datetime.now())

        # check
        happeningToday = (currentDateObject.date() == self.appointmentDate.date())

        return happeningToday
    
    def hasPassedAlready(self, evenNow:bool=False):
        # get todays date
        awareDateAndTime = changeToTimeZone(dateTimeObject=datetime.now())

        # compare
        if evenNow is False:
            itemStatus = changeToTimeZone(dateTimeObject=self.appointmentDate) < awareDateAndTime

        else:
            itemStatus = changeToTimeZone(dateTimeObject=self.appointmentDate ) <= awareDateAndTime

        return itemStatus


    


    





