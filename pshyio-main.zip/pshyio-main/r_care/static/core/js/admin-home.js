const calenderAppointmentViewer = document.getElementById('calendar-appointment-offcanvas');

// viewer inputs
const timeStampInput = document.getElementById('meeting-stamp-input');

const doctorNameInput = document.getElementById('appointment-doctor-input');

const patientNameInput = document.getElementById('appointment-patient-input');

const appointmentCategory = document.getElementById('appointment-category-input');

const appointmentDescription = document.getElementById('appointment-description-input');

const appointmentDetailsInput = document.getElementById('appointment-details-input');

// modal dump tag
const modalDumpTagInput = document.getElementById('dump-tag-input');

const dumpModal = document.getElementById('dump-appointment-modal');

// approve
const approveTagInput = document.getElementById('approve-tag-input');

const approveCanvas = document.getElementById('approve-appointment-offcanvas');

const otherInputsHold = document.getElementById('other-inputs-holder');

// cancel
const cancellationTagInput = document.getElementById('cancellation-tag-input');

const cancelModal = document.getElementById('confirm-cancellation-modal');

// completed
const completeTagInput = document.getElementById('completed-tag-input');

const completeModal = document.getElementById('confirm-complete-modal');


document.addEventListener("DOMContentLoaded", function () {
    dumpModal.addEventListener('hide.bs.modal', (hideEvent) => {
        // on close
        modalDumpTagInput.value = "";
    });

    if (approveTagInput){
        approveCanvas.addEventListener('hide.bs.offcanvas', (hideEvent) => {
            // close
            approveTagInput.value = "";

            otherInputsHold.innerHTML = "";

            if (!otherInputsHold.classList.contains('d-none')){
                otherInputsHold.classList.add('d-none')
            }
        });
    }
    

    // track clicks
    document.querySelectorAll('.dump-trigger').forEach(eachDumpTrigger => {
        eachDumpTrigger.addEventListener('click', (clickEvent)=>{
            // get the tag
            let tagOfRequest = eachDumpTrigger.getAttribute('data-dump-target');

            // debug
            console.log('Tag:', tagOfRequest)

            modalDumpTagInput.value = tagOfRequest;
        });
    });

    document.querySelectorAll('.approve-trigger').forEach(eachApproveTrigger => {
        eachApproveTrigger.addEventListener('click', (clickEvent)=>{
            // get the tag
            let tagOfRequest = eachApproveTrigger.getAttribute('data-approve-target');

            // debug
            // console.log('Tag:', tagOfRequest)

            approveTagInput.value = tagOfRequest;

            // check the meeting type
            let meetingType = parseInt(eachApproveTrigger.getAttribute('data-meeting-type'));

            if (meetingType === 2){
                let meetingLinkInput = `
                                        <label class="form-label" for="meeting-link-input">
                                            <i class="bx bx-link me-1"></i>
                                            Meeting Link
                                        </label>

                                        <div class="input-group">
                                            <input type="text" id="meeting-link-input" name="meeting-link" placeholder="Link for google meeting" class="form-control" required>
                                            
                                            <a href="https://meet.google.com/" target="_blank" class="input-group-text">
                                                <i class="bx bx-plus-circle me-1"></i>

                                                Get Link
                                            </a>
                                        </div>
                `;

                otherInputsHold.innerHTML = meetingLinkInput;

                // unhide container
                if (otherInputsHold.classList.contains('d-none')){
                    otherInputsHold.classList.remove('d-none')
                }

            }else{
                // its a physical meeting
            }
        });
    });

    cancelModal.addEventListener('hide.bs.modal', (hideEvent) => {
        // reset
        cancellationTagInput.value = "";
    });

    document.querySelectorAll('.trigger-cancellation').forEach(eachCancellationTrigger => {
        eachCancellationTrigger.addEventListener('click', (clickEvent)=>{
            // get the tag
            let appointmentTag = eachCancellationTrigger.getAttribute('data-cancel-tag');

            // debug
            // console.log('Tag:', appointmentTag)

            cancellationTagInput.value = appointmentTag;
        });
    });


    completeModal.addEventListener('hide.bs.modal', (hideEvent) => {
        // reset complete tag
        completeTagInput.value = "";
    });


    document.querySelectorAll('.completed-trigger').forEach(completedTrigger => {
        completedTrigger.addEventListener('click', (clickEvent)=>{
            // get the tag
            let appointmentTag = completedTrigger.getAttribute('data-completed-tag');

            // debug
            // console.log('Tag:', appointmentTag)

            completeTagInput.value = appointmentTag;
        });
    });

    


    function handleEventClick(calendarEvent) {
        // console.log(calendarEvent);

        timeStampInput.innerHTML = `On ${calendarEvent.meeting_date} At ${calendarEvent.start_time}`;
    
        doctorNameInput.value = calendarEvent.doctor;

        patientNameInput.value = calendarEvent.client;

        appointmentCategory.value = calendarEvent.type;

        appointmentDescription.value = calendarEvent.description;

        appointmentDetailsInput.value = calendarEvent.details;

        // display details
        let calendarOffCanvas = new bootstrap.Offcanvas(calenderAppointmentViewer);
    
        calendarOffCanvas.show();
    
    }
    
    
    // get events
    let sampleEvent = {
        id: 'xg562hT',
        title: 'Meeting',
        doctor: 'Peter Mercy',
        client: 'Joyce Joel',
        type: 'online',
        start_time: '12:60 PM',
        meeting_date: '13-36-2024',
        start: '2024-04-01T11:00:00',
        className: 'bg-success',
        description: 'Test  event'
    }
  
    // Initialize FullCalendar with jQuery
    $("#calendar").fullCalendar({
        header: {
        left: "prev,next today",
        center: "title",
        right: "month,basicWeek,basicDay",
        },
        selectable: true,
        selectHelper: true,
        events: '/get-events/',
        // events: [sampleEvent], 
        eventClick: function (calEvent, jsEvent, view) {
        handleEventClick(calEvent);
        },

    });

});