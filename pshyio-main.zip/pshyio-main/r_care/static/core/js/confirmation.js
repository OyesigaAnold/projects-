
const formTagInput = document.getElementById('p-tag-input');


document.addEventListener('DOMContentLoaded', ()=>{
    // track wipes
    document.querySelectorAll('.wipe-trigger').forEach(eachWipeTrigger => {
        eachWipeTrigger.addEventListener('click', (clickEvent)=>{
            // get the tag
            let foundPTag = eachWipeTrigger.getAttribute('data-ref-tag');

            // debug
            // console.log('Gotten:', foundPTag)

            // load the tag
            formTagInput.value = foundPTag;
        });
    });

});