const newPasswordField = document.getElementById('new-password-input');

const confirmPasswordField = document.getElementById('confirm-password-input');

const submitChangesTrigger = document.getElementById('submit-changes-trigger');


function toggleInputElement(elementToToggle){
    if (elementToToggle.type === 'password'){
        elementToToggle.type = 'text';

    } else {
        elementToToggle.type = 'password';
    }

}


function seeIfPasswordsMath(){
    let matchStatus = confirmPasswordField.value === newPasswordField.value;

    // activate or deactivate the button
    submitChangesTrigger.disabled = !matchStatus;
}


document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.password-toggle').forEach(passwordToggle => {
        passwordToggle.addEventListener('click', () => {
            // get the target
            let attachedTarget = document.getElementById(passwordToggle.getAttribute("data-changes"));

            // update the state
            toggleInputElement(attachedTarget);
        });
    });

    document.querySelectorAll('.needs-validation').forEach(eachInputElement => {
        eachInputElement.addEventListener('input', () => {
            // track if passwords match
            seeIfPasswordsMath();

            // debug
            // console.log('validated');
        });
    });
})