
function grabToken(){
    // get the token holder
    let tokenHolder = document.getElementById('reset-bait-area').querySelector('input[name="csrfmiddlewaretoken"]');

    // get the token
    let foundToken = tokenHolder.value;

    return foundToken;
}

function triggerEmailVerification(){
    // get the token
    let csrfToken = grabToken();

    axios.post('/do-verification', {}, 
    {
        headers: {
            'X-CSRFToken': csrfToken,
        }
    })
    .then(response => {
        // clean up
        document.getElementById('reset-bait-area').remove();

        console.log('Done');
        
    })
    .catch(foundError => {
        console.log('Failed')

        console.log(foundError)
    });

}

document.addEventListener('DOMContentLoaded', ()=>{
    let resetTrigger = document.getElementById('reset-bait-area');

    if (resetTrigger && navigator.onLine){

        // trigger email verification
        triggerEmailVerification();
    } else {

    }
});