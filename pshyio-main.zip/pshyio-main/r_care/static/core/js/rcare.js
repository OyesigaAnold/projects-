"use strict";
var Popover = (function () {
    var t = $('[data-toggle="popover"]');
    t.length &&
      t.each(function () {
        !(function (t) {
          var e = "";
          t.data("color") && (e = " popover-" + t.data("color"));
          var a = {
            trigger: "focus",
            template:
              '<div class="popover' +
              e +
              '" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div><div class="popover-navigation"><button class="btn btn-primary" data-role="prev">« Prev</button><button class="btn btn-primary" data-role="next">Next »</button><button class="btn btn-primary" data-role="end">End tour</button></div></div>',
          };
          t.popover(a), t.popover("show");
        })($(this));
      });
  })(),
  PurposeStyle = (function () {
    var t = getComputedStyle(document.body);
    return {
      colors: {
        gray: {
          100: "#f6f9fc",
          200: "#e9ecef",
          300: "#dee2e6",
          400: "#ced4da",
          500: "#adb5bd",
          600: "#8898aa",
          700: "#525f7f",
          800: "#32325d",
          900: "#212529",
        },
        theme: {
          primary: t.getPropertyValue("--primary")
            ? t.getPropertyValue("--primary").replace(" ", "")
            : "#008aff",
          info: t.getPropertyValue("--info")
            ? t.getPropertyValue("--info").replace(" ", "")
            : "#50b5ff",
          success: t.getPropertyValue("--success")
            ? t.getPropertyValue("--success").replace(" ", "")
            : "#5cc9a7",
          danger: t.getPropertyValue("--danger")
            ? t.getPropertyValue("--danger").replace(" ", "")
            : "#f25767",
          warning: t.getPropertyValue("--warning")
            ? t.getPropertyValue("--warning").replace(" ", "")
            : "#FFBE3D",
          dark: t.getPropertyValue("--dark")
            ? t.getPropertyValue("--dark").replace(" ", "")
            : "#171347",
        },
        transparent: "transparent",
      },
      fonts: {
        base: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"',
      },
    };
  })(),
  SvgInjector = (function () {
    var t = document.querySelectorAll("img.svg-inject"),
      e = !1;
    return (
      t.length &&
        SVGInjector(t, {}, function () {
          e = !0;
        }),
      { status: e }
    );
  })(),
  Tooltip = (function () {
    var t = $('[data-toggle="tooltip"]');
    t.length && t.tooltip();
  })(),
  CopyType = (function () {
    var t,
      e = ".btn-type-clipboard",
      a = $(e);
    a.length &&
      ((t = a).tooltip().on("mouseleave", function () {
        t.tooltip("hide");
      }),
      new ClipboardJS(e).on("success", function (t) {
        $(t.trigger)
          .attr("title", "Copied!")
          .tooltip("_fixTitle")
          .tooltip("show")
          .attr("title", "Copy to clipboard")
          .tooltip("_fixTitle"),
          t.clearSelection();
      }));
  })(),
  DarkMode = (function () {
    var i = document.getElementById("btnSwitchMode"),
      s = document.getElementById("stylesheet"),
      t = {
        mode: localStorage.getItem("mode")
          ? localStorage.getItem("mode")
          : null,
      };
    function e(t, e) {
      if (t) {
        var a,
          o = s.getAttribute("href").split("/"),
          n = o[o.length - 1];
        (a = "dark" == t ? "quick-website-dark.css" : "quick-website.css"),
          (a = s.getAttribute("href").replace(n, a)),
          s.setAttribute("href", a),
          localStorage.setItem("mode", t),
          "dark" == t
            ? (i.classList.add("text-warning"),
              i.setAttribute("data-mode", "light"))
            : (i.classList.remove("text-warning"),
              i.setAttribute("data-mode", "dark")),
          document.getElementById("header-main") &&
            (function (t) {
              var e,
                a = document.getElementById("header-main"),
                o = document.getElementById("navbar-main"),
                n = document.getElementById("navbar-logo"),
                i = n.getAttribute("src").split("/"),
                s = i[i.length - 1];
              a.classList.contains("header-transparent") ||
                ((e =
                  "dark" == t
                    ? (o.classList.remove("navbar-light", "bg-white"),
                      o.classList.add("navbar-dark", "bg-dark"),
                      n.getAttribute("src").replace(s, "light.svg"))
                    : (o.classList.remove("navbar-dark", "bg-dark"),
                      o.classList.add("navbar-light", "bg-white"),
                      n.getAttribute("src").replace(s, "dark.svg"))),
                n.setAttribute("src", e));
            })(t),
          e && e();
      }
    }
    i &&
      s &&
      (window.addEventListener("load", function () {
        e(t.mode, function () {
          document.body.style.opacity = "1";
        });
      }),
      i.addEventListener("click", function () {
        var t = i.dataset.mode;
        (document.body.style.opacity = "0"),
          e(t, function () {
            document.body.style.opacity = "1";
          });
      }));
  })(),
  Demo = void $('[data-toggle="sweet-alert"]').on("click", function () {
    switch ($(this).data("sweet-alert")) {
      case "basic":
        Swal.fire({
          title: "Here's a message!",
          text: "A few words about this sweet alert ...",
          buttonsStyling: !1,
          confirmButtonClass: "btn btn-primary",
        });
        break;
      case "info":
      case "info":
        Swal.fire({
          title: "Info",
          text: "A few words about this sweet alert ...",
          type: "info",
          buttonsStyling: !1,
          confirmButtonClass: "btn btn-info",
        });
        break;
      case "success":
        Swal.fire({
          title: "Success",
          text: "A few words about this sweet alert ...",
          type: "success",
          buttonsStyling: !1,
          confirmButtonClass: "btn btn-success",
        });
        break;
      case "warning":
        Swal.fire({
          title: "Warning",
          text: "A few words about this sweet alert ...",
          type: "warning",
          buttonsStyling: !1,
          confirmButtonClass: "btn btn-warning",
        });
        break;
      case "question":
        Swal.fire({
          title: "Are you sure?",
          text: "A few words about this sweet alert ...",
          type: "question",
          buttonsStyling: !1,
          confirmButtonClass: "btn btn-dark",
        });
        break;
      case "confirm":
        Swal.fire({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: !0,
          buttonsStyling: !1,
          confirmButtonClass: "btn btn-danger",
          confirmButtonText: "Yes, delete it!",
          cancelButtonClass: "btn btn-secondary",
        }).then(function (t) {
          t.value &&
            Swal.fire({
              title: "Deleted!",
              text: "Your file has been deleted.",
              type: "success",
              buttonsStyling: !1,
              confirmButtonClass: "btn btn-primary",
            });
        });
        break;
      case "image":
        Swal.fire({
          title: "Sweet",
          text: "Modal with a custom image ...",
          imageUrl: "../../assets/img/prv/splash.png",
          buttonsStyling: !1,
          confirmButtonClass: "btn btn-primary",
          confirmButtonText: "Super!",
        });
        break;
      case "timer":
        Swal.fire({
          title: "Auto close alert!",
          text: "I will close in 2 seconds.",
          timer: 2e3,
          showConfirmButton: !1,
        });
    }
  }),
  Dropdown = (function () {
    var t = $(".dropdown-animate"),
      e = $('.dropdown-submenu [data-toggle="dropdown"]');
    t.length &&
      t.on({
        "hide.bs.dropdown": function (t) {
          !(function (t) {
            var e = t.find(".dropdown-menu");
            e.addClass("hide"),
              setTimeout(function () {
                e.removeClass("hide");
              }, 300);
          })($(this));
        },
      }),
      e.length &&
        e.on("click", function () {
          return (
            (function (t) {
              t.next().hasClass("show") ||
                t
                  .parents(".dropdown-menu")
                  .first()
                  .find(".show")
                  .removeClass("show");
              var e = t.next(".dropdown-menu");
              e.toggleClass("show"),
                e.parent().toggleClass("show"),
                t
                  .parents(".nav-item.dropdown.show")
                  .on("hidden.bs.dropdown", function () {
                    $(".dropdown-submenu .show").removeClass("show");
                  });
            })($(this)),
            !1
          );
        }),
      $(".dropdown-menu").on("click", function (t) {
        var e = $._data(document, "events") || {};
        e = e.click || [];
        for (var a = 0; a < e.length; a++)
          e[a].selector &&
            ($(t.target).is(e[a].selector) && e[a].handler.call(t.target, t),
            $(t.target)
              .parents(e[a].selector)
              .each(function () {
                e[a].handler.call(this, t);
              }));
        t.stopPropagation();
      });
  })(),
  FormControl = (function () {
    var t = $(".form-control"),
      e = $('[data-toggle="indeterminate"]');
    t.length &&
      t
        .on("focus blur", function (t) {
          $(this)
            .parents(".form-group")
            .toggleClass("focused", "focus" === t.type);
        })
        .trigger("blur"),
      e.length &&
        e.each(function () {
          $(this).prop("indeterminate", !0);
        });
  })(),
  CustomInputFile = (function () {
    var t = $(".custom-input-file");
    t.length &&
      t.each(function () {
        var e = $(this);
        e.on("change", function (t) {
          !(function (t, e, a) {
            var o,
              n = t.next("label"),
              i = n.html();
            e && 1 < e.files.length
              ? (o = (e.getAttribute("data-multiple-caption") || "").replace(
                  "{count}",
                  e.files.length
                ))
              : a.target.value && (o = a.target.value.split("\\").pop()),
              o ? n.find("span").html(o) : n.html(i);
          })(e, this, t);
        }),
          e
            .on("focus", function () {
              !(function (t) {
                t.addClass("has-focus");
              })(e);
            })
            .on("blur", function () {
              !(function (t) {
                t.removeClass("has-focus");
              })(e);
            });
      });
  })(),
  NavbarSticky = (function () {
    var t = $(".navbar-sticky"),
      o = 0,
      e = !1;
    t.length &&
      ((o = t.offset().top),
      $(window).on({
        scroll: function () {
          (e = !0),
            setInterval(function () {
              e &&
                ((e = !1),
                (function (t) {
                  var e = $(window).scrollTop(),
                    a = t.outerHeight();
                  o + 200 < e
                    ? (t.addClass("sticky"),
                      $("body").css("padding-top", a + "px"))
                    : (t.removeClass("sticky"),
                      $("body").css("padding-top", "0"));
                })(t));
            }, 250);
        },
      }));
  })(),
  PasswordText = (function () {
    var t = $('[data-toggle="password-text"]');
    t.length &&
      t.on("click", function () {
        !(function (t) {
          var e = $(t.data("target"));
          "password" == e.attr("type")
            ? e.attr("type", "text")
            : e.attr("type", "password");
        })($(this));
      });
  })(),
  Pricing = (function () {
    var t = $(".pricing-container"),
      e = $(".pricing-container button[data-pricing]");
    t.length &&
      e.on({
        click: function () {
          !(function (t) {
            t.data("pricing");
            var e = t.parents(".pricing-container"),
              a = $("." + e.attr("class") + " [data-pricing-value]");
            t.hasClass("active") ||
              ($("." + e.attr("class") + " button[data-pricing]").removeClass(
                "active"
              ),
              t.addClass("active"),
              a.each(function () {
                var t = $(this).data("pricing-value"),
                  e = $(this).find("span.price").text();
                $(this).find("span.price").text(t),
                  $(this).data("pricing-value", e);
              }));
          })($(this));
        },
      });
  })(),
  ScrollTo = (function () {
    var t = $(".scroll-me, [data-scroll-to], .toc-entry a"),
      e = window.location.hash;
    t.length &&
      t.on("click", function () {
        !(function (t) {
          var e = t.attr("href"),
            a = t.data("scroll-to-offset") ? t.data("scroll-to-offset") : 0,
            o = { scrollTop: $(e).offset().top - a };
          $("html, body").stop(!0, !0).animate(o, 300), event.preventDefault();
        })($(this));
      }),
      $(window).on("load", function () {
        e &&
          "#!" != e &&
          $(e).length &&
          (function (t) {
            $("html, body").animate({ scrollTop: $(t).offset().top }, "slow");
          })(e);
      });
  })(),
  GoogleMapCustom = (function () {
    var i,
      s,
      r,
      l,
      t = document.getElementById("map-custom");
    void 0 !== t &&
      null != t &&
      google.maps.event.addDomListener(
        window,
        "load",
        (function (t) {
          (i = t.getAttribute("data-lat")),
            (s = t.getAttribute("data-lng")),
            (r = t.getAttribute("data-color")),
            (l = t.getAttribute("data-zoom")
              ? parseInt(t.getAttribute("data-zoom"))
              : 12);
          var e = new google.maps.LatLng(i, s),
            a = {
              zoom: l,
              scrollwheel: !1,
              center: e,
              mapTypeId: google.maps.MapTypeId.ROADMAP,
              styles: [
                {
                  featureType: "administrative",
                  elementType: "labels.text.fill",
                  stylers: [{ color: "#444444" }],
                },
                {
                  featureType: "landscape",
                  elementType: "all",
                  stylers: [{ color: "#f2f2f2" }],
                },
                {
                  featureType: "poi",
                  elementType: "all",
                  stylers: [{ visibility: "off" }],
                },
                {
                  featureType: "road",
                  elementType: "all",
                  stylers: [{ saturation: -100 }, { lightness: 45 }],
                },
                {
                  featureType: "road.highway",
                  elementType: "all",
                  stylers: [{ visibility: "simplified" }],
                },
                {
                  featureType: "road.arterial",
                  elementType: "labels.icon",
                  stylers: [{ visibility: "off" }],
                },
                {
                  featureType: "transit",
                  elementType: "all",
                  stylers: [{ visibility: "off" }],
                },
                {
                  featureType: "water",
                  elementType: "all",
                  stylers: [{ color: r }, { visibility: "on" }],
                },
              ],
            };
          t = new google.maps.Map(t, a);
          var o = new google.maps.Marker({
              position: e,
              map: t,
              animation: google.maps.Animation.DROP,
              title: "Hello World!",
            }),
            n = new google.maps.InfoWindow({
              content:
                '<div class="info-window-content"><h5>Company Name</h5><p>Description comes here...</p></div>',
            });
          google.maps.event.addListener(o, "click", function () {
            n.open(t, o);
          });
        })(t)
      );
  })(),
  GoogleMap = (function () {
    var i,
      s,
      r,
      t = document.getElementById("map-default");
    void 0 !== t &&
      null != t &&
      google.maps.event.addDomListener(
        window,
        "load",
        (function (t) {
          (i = t.getAttribute("data-lat")),
            (s = t.getAttribute("data-lng")),
            (r = t.getAttribute("data-zoom")
              ? parseInt(t.getAttribute("data-zoom"))
              : 12);
          var e = new google.maps.LatLng(i, s),
            a = {
              zoom: r,
              scrollwheel: !1,
              center: e,
              mapTypeId: google.maps.MapTypeId.ROADMAP,
            };
          t = new google.maps.Map(t, a);
          var o = new google.maps.Marker({
              position: e,
              map: t,
              animation: google.maps.Animation.DROP,
              title: "Hello World!",
            }),
            n = new google.maps.InfoWindow({
              content:
                '<div class="info-window-content"><h2>{{ site.product.name }} {{ site.product.name_long }}</h2><p>{{ site.product.description }}</p></div>',
            });
          google.maps.event.addListener(o, "click", function () {
            n.open(t, o);
          });
        })(t)
      );
  })(),
  TextareaAutosize = (function () {
    var t = $('[data-toggle="autosize"]');
  })(),
  Countdown = (function () {
    var t = $(".countdown");
    t.length &&
      t.each(function () {
        !(function (t) {
          var e = t.data("countdown-date");
          t.countdown(e).on("update.countdown", function (t) {
            $(this).html(
              t.strftime(
                '<div class="countdown-item"><span class="countdown-digit">%-D</span><span class="countdown-label countdown-days">day%!D</span></div><div class="countdown-item"><span class="countdown-digit">%H</span><span class="countdown-separator">:</span><span class="countdown-label">hrs</span></div><div class="countdown-item"><span class="countdown-digit">%M</span><span class="countdown-separator">:</span><span class="countdown-label">min</span></div><div class="countdown-item"><span class="countdown-digit">%S</span><span class="countdown-label">sec</span></div>'
              )
            );
          });
        })($(this));
      });
  })();
!(function (d) {
  (d.fn.countTo = function (c) {
    return (
      (c = c || {}),
      d(this).each(function () {
        var a = d.extend(
            {},
            d.fn.countTo.defaults,
            {
              from: d(this).data("from"),
              to: d(this).data("to"),
              speed: d(this).data("speed"),
              refreshInterval: d(this).data("refresh-interval"),
              decimals: d(this).data("decimals"),
            },
            c
          ),
          t = Math.ceil(a.speed / a.refreshInterval),
          e = (a.to - a.from) / t,
          o = this,
          n = d(this),
          i = 0,
          s = a.from,
          r = n.data("countTo") || {};
        function l(t) {
          var e = a.formatter.call(o, t, a);
          n.text(e);
        }
        n.data("countTo", r),
          r.interval && clearInterval(r.interval),
          (r.interval = setInterval(function () {
            i++,
              l((s += e)),
              "function" == typeof a.onUpdate && a.onUpdate.call(o, s),
              t <= i &&
                (n.removeData("countTo"),
                clearInterval(r.interval),
                (s = a.to),
                "function" == typeof a.onComplete && a.onComplete.call(o, s));
          }, a.refreshInterval)),
          l(s);
      })
    );
  }),
    (d.fn.countTo.defaults = {
      from: 0,
      to: 0,
      speed: 1e3,
      refreshInterval: 100,
      decimals: 0,
      formatter: function (t, e) {
        return t.toFixed(e.decimals);
      },
      onUpdate: null,
      onComplete: null,
    });
})(jQuery);

Highlight = void $(".highlight").each(function (t, e) {
  !(function (t, e) {
    $(e).before(
      '<button class="action-item btn-clipboard" title="Copy to clipboard"><i data-feather="copy"></i></button>'
    ),
      $(".btn-clipboard")
        .tooltip()
        .on("mouseleave", function () {
          $(this).tooltip("hide");
        });
    var a = new ClipboardJS(".btn-clipboard", {
      target: function (t) {
        return t.nextElementSibling;
      },
    });
    a.on("success", function (t) {
      $(t.trigger)
        .attr("title", "Copied!")
        .tooltip("_fixTitle")
        .tooltip("show")
        .attr("title", "Copy to clipboard")
        .tooltip("_fixTitle"),
        t.clearSelection();
    }),
      a.on("error", function (t) {
        var e =
          "Press " +
          (/Mac/i.test(navigator.userAgent) ? "⌘" : "Ctrl-") +
          "C to copy";
        $(t.trigger)
          .attr("title", e)
          .tooltip("_fixTitle")
          .tooltip("show")
          .attr("title", "Copy to clipboard")
          .tooltip("_fixTitle");
      }),
      hljs.highlightBlock(e);
  })(0, e);
});

//# sourceMappingURL=quick-website.js.map
