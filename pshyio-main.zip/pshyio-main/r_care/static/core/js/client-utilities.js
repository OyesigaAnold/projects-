const meetingIdInput = document.getElementById('meeting-id-input');

// date and time
const requestDateInput = document.getElementById('request-stamp-input');

const requestTimeInput = document.getElementById('request-time-input');

// method
const requestMethodInput = document.getElementById('request-category-input');

// details
const requestDetailsInput = document.getElementById('appointment-details-input');

// request offcanvas
const newRequestOffCanvas = document.getElementById('new-appointment-request-offcanvas');

// cancel

// modal dump tag
const modalApprovedTagInput = document.getElementById('approved-tag-input');

const approvedCancelModal = document.getElementById('cancel-approved-modal');


function getTodaysDate(){
    let todayDate = new Date();

    // Get the year, month, and day components of the date
    let year = todayDate.getFullYear();

    let month = String(todayDate.getMonth() + 1).padStart(2, '0'); 

    // Months are zero-based
    let day = String(todayDate.getDate()).padStart(2, '0');

    // Format the date in "YYYY-MM-DD" format
    let formattedDate = year + '-' + month + '-' + day;

    return formattedDate;
}



document.addEventListener('DOMContentLoaded', ()=>{
    newRequestOffCanvas.addEventListener('hide.bs.offcanvas', (hideEvent) => {
        meetingIdInput.value = "";

        requestDateInput.value = getTodaysDate();

        requestDetailsInput.value = "";

        requestMethodInput.value = "1";
    });


    document.querySelectorAll('.edit-request').forEach(eachEditRequestButton => {
        eachEditRequestButton.addEventListener('click', (clickEvent) => {
            // get the id
            let idOfAppointment = eachEditRequestButton.getAttribute('data-edit-target');

            // debug
            // console.log(idOfAppointment);

            // ensure that an update is made
            meetingIdInput.value = idOfAppointment;

            // load other details
            requestDateInput.value = eachEditRequestButton.getAttribute('data-ref-date');

            requestTimeInput.value = eachEditRequestButton.getAttribute('data-ref-time');

            // method
            let refMethod = eachEditRequestButton.getAttribute('data-ref-method');

            requestMethodInput.value = refMethod;

            // details
            let refDetails = eachEditRequestButton.getAttribute('data-ref-details');

            // particulars
            requestDetailsInput.value = refDetails;

        });
    });


    approvedCancelModal.addEventListener('hide.bs.modal', (hideEvent) => {
        // reset
        modalApprovedTagInput.value = "";
    });

    document.querySelectorAll('.approved-cancel').forEach(approvedCancellationTrigger => {
        approvedCancellationTrigger.addEventListener('click', (clickEvent)=>{
            // get the tag
            let appointmentTag = approvedCancellationTrigger.getAttribute('data-approved-tag');

            // debug
            // console.log('Tag:', appointmentTag)

            modalApprovedTagInput.value = appointmentTag;
        });
    });



});