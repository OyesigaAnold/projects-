
const tokenBait = document.getElementById('token-bait-area');

const markSeenButton = document.getElementById('see-contact-messages');

const contactMessagesCounter = document.getElementById('contact-message-counter');

const deleteAllTriggerContainer = document.getElementById('delete-all-button-container');

const messageItemsContainer = document.getElementById('message-items-container');

const deleteAllContactMessages = document.getElementById('delete-all-button');

const closeMessagesOffCanvas = document.getElementById('close-cmsg-offcanvas');


function grabToken(){
    // get the token holder
    let tokenHolder = tokenBait.querySelector('input[name="csrfmiddlewaretoken"]');

    // get the token
    let foundToken = tokenHolder.value;

    return foundToken;
}

function markAvailableMessageBatchSeen(){
    // get the token
    let csrfToken = grabToken();

    axios.post('/whisper-seen/', {}, {
        headers: {
            'X-CSRFToken': csrfToken
        }
    })
    .then(response => {
        // clean up
        cleanUpInterface();
    })
    .catch(foundError => {});

}

function cleanUpInterface(){
    // reset counter
    markSeenButton.setAttribute('data-contact-messages', '0');

    // get rid of the counter
    contactMessagesCounter.remove();
}

function cleanUpAfterContactMessageWipe(){
    // check how many items are remaining
    let contactMessageCount = document.querySelectorAll('.message-item').length;

    if (contactMessageCount === 0){
        // show that there no messages
        messageItemsContainer.innerHTML =  `
                                            <div class="d-flex justify-content-center p-5">
                                                <p class="card-text">No suggestions yet</p>
                                            </div>
                                            `;

        // get rid of the delete all button
        deleteAllTriggerContainer.remove()
    }


}

function executeMessageDump(messageTag, dumpTrigger){
    // get the token
    let csrfToken = grabToken();

    axios.post('/dump-contact-message/', {
        msg_tag: messageTag
    }, 
    {
        headers: {
            'X-CSRFToken': csrfToken,
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    })
    .then(response => {
        // remove the message from the list
        dumpTrigger.closest('div.message-item').remove();

        // cleanup
        cleanUpAfterContactMessageWipe();
    })
    .catch(foundError => {});

}



document.addEventListener('DOMContentLoaded', () => {

    markSeenButton.addEventListener('click', (clickEvent) => {
        // stop movement
        clickEvent.preventDefault();

        // get the count
        let currentCount = parseInt(markSeenButton.getAttribute('data-contact-messages'));

        // debug
        // console.log('Count:', currentCount);

        if (currentCount > 0){
            // check if there is network
            if (navigator.onLine){
                // proceed and mark seen
                markAvailableMessageBatchSeen();


            } else {
                // no internet
            }

        } else {
            // ignore
            
            // debug
            // console.log('none');
        }

    });

    document.querySelectorAll('.delete-message').forEach(eachDeleteButton => {
        eachDeleteButton.addEventListener('click', (clickEvent) => {
            clickEvent.preventDefault();

            // get the attached id
            let attachedId = eachDeleteButton.getAttribute('data-ref-id');

            // console.log('Token:', attachedId);

            // dump the message
            if (navigator.onLine){
                executeMessageDump(attachedId, eachDeleteButton);
            }
        });
    });

    if (deleteAllContactMessages){
        deleteAllContactMessages.addEventListener('click', (clickEvent)=>{
            clickEvent.preventDefault();
            // hide
            closeMessagesOffCanvas.click();
            
            // did hide
            console.log('hidden');
        });
    }
    
});