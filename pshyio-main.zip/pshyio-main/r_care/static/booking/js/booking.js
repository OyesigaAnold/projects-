const dateHolder = document.getElementById("selected-date-input");

const timeHolder = document.getElementById("selected-time-input");

const appointmentSubmitter = document.getElementById("submit-appointment-button");


// track bio input fields
const firstNameField = document.getElementById('first-name-field');

const lastNameField = document.getElementById('last-name-field');

const emailField = document.getElementById('email-field');

const contactField = document.getElementById('contact-field');

const dateTimeShow = document.getElementById("date-time-show");


function inputIsFilled(inputElement){
    let inputHasSomething = inputElement.value.trim().length > 0;

    return inputHasSomething;
}

function isFormValidForSubmission(){
    // validate if all details are present
    let dateAndTimePresent = dateHolder.value !== "empty" || timeHolder.value !== "empty";

    // validate bio
    let bioIsComplete = inputIsFilled(firstNameField) && inputIsFilled(lastNameField) && 
                        inputIsFilled(emailField) && inputIsFilled(contactField);

    // check if the dates and bio are complete
    let allIsComplete = dateAndTimePresent && bioIsComplete;

    // console.log("Submit the form:", allIsComplete);

    // button state
    let newButtonState = !allIsComplete;

    // activate or deactivate the submit button
    appointmentSubmitter.disabled = newButtonState;

}

function getTodaysDate(){
    // generate a new date object
    let currentDateObject = new Date();

    // get the year, month and day
    let currentYear = currentDateObject.getFullYear();

    let currentMonth = (currentDateObject.getMonth() + 1).toString().padStart(2, '0');

    let currentDay = currentDateObject.getDate().toString().padStart(2, '0');;

    // 2024-03-31
    let dateString = `${currentYear}-${currentMonth}-${currentDay}`;


    return dateString;
}

document.addEventListener('DOMContentLoaded', () => {

    document.querySelectorAll(".appointment-input").forEach(eachInputElement => {
        eachInputElement.addEventListener('input', ()=>{
            // validate the form
            isFormValidForSubmission();
        });
    });

    function stampChanged(clickEvent, calendarObject){
        // get the date
        let selectedDate = calendarObject.selectedDates[0];

        let selectedTime = calendarObject.selectedTime;

        // update the selected date
        selectedDate = (selectedDate === undefined) ? getTodaysDate(): selectedDate;

        // store the date and time
        dateHolder.value = selectedDate;

        timeHolder.value = selectedTime;

        // console.log(`The selected date is ${selectedDate} and time is ${selectedTime}`);

        dateTimeShow.value = `On ${selectedDate} At ${selectedTime}`;

        // validate form
        isFormValidForSubmission();

    }

    const calendar = new VanillaCalendar('#calendar', {
        actions: {
            changeTime(e, self) {
                stampChanged(e, self);
            },

            clickDay(e, self) {
                // console.log(self);
                stampChanged(e, self);
            },
        },

        settings: {
            selection: {
                time: true, // enable time selection
            },
            range: {
                disablePast: true,
            },
        
        },

    });

    calendar.init();
});
