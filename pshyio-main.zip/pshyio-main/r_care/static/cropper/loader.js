const imageSelectorTrigger = document.getElementById("induce-selector-button");

const fileSelectorInput = document.getElementById("file-selector-input");

const uploadPreviewContainer = document.getElementById(
  "uploaded-preview-container"
);

const cardImageContainer = document.getElementById("card-image-container");

const clearButton = document.getElementById("clear-button");

const uploadTriggersContainer = document.getElementById(
  "upload-triggers-container"
);

const inducePreviewButton = document.getElementById("induce-preview-button");

const imageShowCaseArea = document.getElementById("show-case-avatar");

const previewAvatarContainer = document.getElementById("avatar-preview-area");

const avatarContentInput = document.getElementById("avatar-content-input");

const originalAvatarContainer = document.getElementById(
  "original-avatar-container"
);

const avatarControlOffcanvas = document.getElementById(
  "avatar-control-offcanvas"
);

var cropperInstance;

function resetRoutine() {
  // invalidate the cropper js object
  if (cropperInstance) {
    // destroy the object
    cropperInstance.destroy();

    // now set it to undefined
    cropperInstance = undefined;
  }

  // clear form value
  avatarContentInput.value = "";

  if (!previewAvatarContainer.classList.contains("d-none")) {
    previewAvatarContainer.classList.add("d-none");
  }

  if (originalAvatarContainer.classList.contains("d-none")) {
    originalAvatarContainer.classList.remove("d-none");
  }

  if (!uploadTriggersContainer.classList.contains("d-none")) {
    uploadTriggersContainer.classList.add("d-none");
  }

  // hide button
  if (!inducePreviewButton.classList.contains("d-none")) {
    inducePreviewButton.classList.add("d-none");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  imageSelectorTrigger.addEventListener("click", (clickEvent) => {
    // select image
    fileSelectorInput.click();
  });

  fileSelectorInput.addEventListener("change", (fileLoadEvent) => {
    if (fileLoadEvent.target.files.length) {
      // read the file
      const fileReaderInstance = new FileReader();

      //   wait for the image
      fileReaderInstance.onload = (readEvent) => {
        // if there is a string url for the image
        if (readEvent.target.result) {
          // get the url
          let imageUrl = readEvent.target.result;

          let imageElement = document.createElement("img");

          imageElement.setAttribute("src", imageUrl);

          // add the image classes
          imageElement.classList.add("card-img");

          imageElement.classList.add("rounded-5");

          // clear whatever is there
          cardImageContainer.innerHTML = "";

          // add the image to the container
          cardImageContainer.appendChild(imageElement);

          // create  or update the cropper object
          cropperInstance = new Cropper(imageElement, {
            aspectRatio: 1,
            viewMode: 1,
          });

          if (uploadPreviewContainer.classList.contains("d-none")) {
            uploadPreviewContainer.classList.remove("d-none");
          }

          if (inducePreviewButton.classList.contains("d-none")) {
            inducePreviewButton.classList.remove("d-none");
          }

          // reset holder
          avatarContentInput.value = "";

          if (!uploadTriggersContainer.classList.contains("d-none")) {
            uploadTriggersContainer.classList.add("d-none");
          }

          if (!previewAvatarContainer.classList.contains("d-none")) {
            previewAvatarContainer.classList.add("d-none");
          }

          if (originalAvatarContainer.classList.contains("d-none")) {
            originalAvatarContainer.classList.remove("d-none");
          }
        }
      };

      // get the file as dataUrl
      fileReaderInstance.readAsDataURL(fileLoadEvent.target.files[0]);
    }
  });

  inducePreviewButton.addEventListener("click", () => {
    let selectedWidth = 128;

    // console.log("cropper:", cropperInstance);

    // get the new image data
    let newUserAvatar = cropperInstance
      .getCroppedCanvas({
        width: selectedWidth,
        height: selectedWidth,
      })
      .toDataURL();

    // set it for preview
    imageShowCaseArea.setAttribute("src", newUserAvatar);

    // also update the holder
    avatarContentInput.value = newUserAvatar;

    if (!originalAvatarContainer.classList.contains("d-none")) {
      originalAvatarContainer.classList.add("d-none");
    }

    if (previewAvatarContainer.classList.contains("d-none")) {
      previewAvatarContainer.classList.remove("d-none");
    }

    if (uploadTriggersContainer.classList.contains("d-none")) {
      uploadTriggersContainer.classList.remove("d-none");
    }
  });

  clearButton.addEventListener("click", () => {
    // reset
    resetRoutine();
  });

  avatarControlOffcanvas.addEventListener(
    "hidden.bs.offcanvas",
    (hiddenEvent) => {
      resetRoutine();
    }
  );
});
